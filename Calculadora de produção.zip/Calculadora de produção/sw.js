// Suba esta versão a cada deploy para invalidar caches antigos.
const CACHE = "calc-producao-v6";

const PRE_CACHE = [
  "./index.html",
  "./style.css",
  "./app.js",
  "./parametros.json",
  "./manifest.json",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(PRE_CACHE).catch(() => {}))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  const url = new URL(e.request.url);

  // Estratégia network-first para HTML, CSS e JS locais: garante que mudanças apareçam logo,
  // com fallback offline ao cache.
  const isLocalAsset =
    url.origin === location.origin &&
    (url.pathname.endsWith(".html") ||
      url.pathname.endsWith(".css") ||
      url.pathname.endsWith(".js") ||
      url.pathname.endsWith("/") ||
      url.pathname === "/");

  e.respondWith(
    caches.match(e.request).then((cached) => {
      if (isLocalAsset) {
        return fetch(e.request)
          .then((r) => {
            const clone = r.clone();
            if (r.ok) caches.open(CACHE).then((c) => c.put(e.request, clone));
            return r;
          })
          .catch(
            () =>
              cached ||
              caches.match("./index.html") ||
              caches.match("index.html")
          );
      }

      // Demais assets (CDN, parametros.json, imagens): cache-first com refresh em background.
      if (cached) return cached;

      return fetch(e.request)
        .then((r) => {
          const clone = r.clone();
          if (
            r.ok &&
            (url.origin === location.origin ||
              url.hostname.includes("cdn.jsdelivr.net"))
          ) {
            caches.open(CACHE).then((c) => c.put(e.request, clone));
          }
          return r;
        })
        .catch(() => {
          if (
            url.pathname.endsWith(".html") ||
            url.pathname === "/" ||
            url.pathname.endsWith("/")
          ) {
            return (
              caches.match("./index.html") || caches.match("index.html")
            );
          }
          if (url.pathname.endsWith("parametros.json")) {
            return caches.match("./parametros.json");
          }
          return new Response("", { status: 503 });
        });
    })
  );
});
