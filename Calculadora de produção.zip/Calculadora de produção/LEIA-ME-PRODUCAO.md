# Calculadora de Produção - Guia para colocar em produção

Este kit roda em **qualquer PC com Windows 10/11** **sem precisar instalar nada**:
não exige Node.js, Python, Docker, IIS ou qualquer outra coisa. O servidor é
escrito em PowerShell puro, que já vem no Windows.

## Você tem dois modelos de implantação. Escolha o que faz mais sentido:

| Modelo | Quando usar | Como funciona |
|---|---|---|
| **A. Servidor central** | Você tem um PC dedicado, e os operadores acessam pelo navegador da rede | Liga o servidor em UM PC. Operadores digitam `http://NOME-DO-PC:8080/` |
| **B. Pasta de rede** | Você quer só largar os arquivos num compartilhamento | Coloca a pasta em `\\servidor\calculadora`. Cada operador clica num atalho que abre tudo localmente no PC dele |

> Os dois modelos são totalmente sem instalação. A diferença é só onde o
> servidor roda. Use o que for mais conveniente — você pode até misturar.

---

## Estrutura de arquivos do kit

| Arquivo | O que faz | Quando usar |
|---|---|---|
| **`abrir-calculadora-da-rede.bat`** | Cada operador clica para abrir no PC dele lendo da pasta de rede | **Modelo B (pasta de rede)** |
| **`criar-atalho-na-area-de-trabalho.bat`** | Cria um atalho bonito no Desktop do operador (com ícone) | Modelo B, **uma vez por operador**, opcional |
| `iniciar-servidor.bat` | Liga o servidor central (janela preta) | **Modelo A (servidor central)** |
| `parar-servidor.bat` | Desliga o servidor central | Modelo A |
| `instalar-acl.bat` | Libera acesso pela rede | Modelo A, **uma vez**, como admin |
| `iniciar-no-boot.bat` | Faz subir junto com o Windows | Modelo A, opcional |
| `servir.ps1` | O servidor em si (chamado pelos .bat) | (não mexa) |
| `_instalar-atalho.ps1` | Lógica do atalho (chamado pelo .bat) | (não mexa) |
| `_serve.js` | Servidor alternativo em Node.js | (não mexa; só se preferir Node) |

E os arquivos da aplicação (`index.html`, `app.js`, `style.css`, `parametros.json`,
`manifest.json`, `sw.js`, ícones e o XLSX de exemplo).

---

# Modelo B - Pasta de rede (sem servidor central)

**Quando usar:** você quer um deploy ainda mais simples — só largar os arquivos
num compartilhamento da empresa, e cada operador clica num atalho que abre
no PC dele. Nenhuma máquina precisa rodar como "servidor".

## Passo 1 - Colocar a pasta no compartilhamento

1. Copie a pasta inteira (todos os arquivos: `index.html`, `app.js`,
   `style.css`, `servir.ps1`, todos os `.bat`, etc.) para a pasta de rede
   da empresa, por exemplo:
   ```
   \\servidor-arquivos\publicos\Calculadora\
   ```
   Ou para um drive mapeado:
   ```
   Z:\Calculadora\
   ```
2. Garanta que os operadores têm permissão de **leitura** (não precisam de
   escrita).

## Passo 2 - Cada operador usa pela primeira vez

Em cada PC operador, basta:

1. **Navegar até a pasta de rede** no Explorador de Arquivos.
2. **Duplo clique em `abrir-calculadora-da-rede.bat`**.
3. O Windows pode mostrar um aviso de segurança (arquivo da rede). Clique em
   **"Executar"** ou **"Mais informações" → "Executar assim mesmo"** se aparecer.
4. Vai abrir uma janela preta (servidor leve) e o **navegador automaticamente**
   com a calculadora.

## Passo 3 (opcional, recomendado) - Criar atalho bonito na Área de Trabalho

Pra evitar que o operador tenha que navegar até a pasta de rede toda vez:

1. **Duplo clique em `criar-atalho-na-area-de-trabalho.bat`** (na pasta de rede).
2. Aparece uma janela preta por 1-2 segundos.
3. Pronto: agora há um atalho **"Calculadora de Producao"** com ícone azul
   na Área de Trabalho dele.

O atalho aponta automaticamente para `abrir-calculadora-da-rede.bat` da pasta
de rede — funciona com qualquer caminho (UNC, drive mapeado, etc.). O ícone
é gerado automaticamente (`icone.ico` na pasta da calculadora) com a identidade
visual do app.

> Isso precisa ser feito **uma vez por operador**, no PC dele.
> Depois, no dia-a-dia, ele só clica no atalho da Área de Trabalho.

> **Para distribuir em massa:** se a empresa tem login script ou GPO, basta
> apontar o login script para `\\servidor\calculadora\criar-atalho-na-area-de-trabalho.bat`
> que ele se instala silenciosamente em todos os PCs do domínio.

## Como funciona por baixo dos panos

- O `.bat` chama o `servir.ps1` da mesma pasta (rede), apontando para a própria
  pasta como raiz.
- O servidor sobe **no PC do operador**, escutando em `http://localhost:8080/`
  (ou a primeira porta livre 8080..8099 — permite vários operadores no mesmo PC).
- Como é localhost, **não precisa de admin, não precisa de firewall, não
  precisa de URL ACL**.
- Os arquivos da calculadora são lidos da pasta de rede em tempo real. Performance
  é ótima porque eles são pequenos (~150 KB total).
- Quando o operador fecha a janela preta, o servidor encerra. Sem processo
  zumbi.

## Atualizando a calculadora (modelo B)

1. Substitua os arquivos na pasta de rede (`index.html`, `app.js`, `style.css`).
2. Incremente o cache no `sw.js`:
   ```js
   const CACHE = "calc-producao-v7";  // bumpe a versão
   ```
3. Os operadores não precisam fazer nada. Da próxima vez que abrirem, já
   vai pegar a versão nova. (Podem precisar de um `Ctrl + F5` se o navegador
   tiver cache antigo.)

## Limitações conhecidas do modelo B

- **GPO da empresa pode bloquear PS1 da rede.** Se ao clicar no `.bat` aparecer
  algo como "execução de scripts está desabilitada", a TI configurou política
  restritiva. Soluções (em ordem de simplicidade):
  - Copiar a pasta para um local **local** do PC (ex: `C:\Calculadora`) e rodar
    de lá.
  - Pedir à TI para liberar `Unrestricted` ou `RemoteSigned` para o domínio.
  - Trocar para o **modelo A** (servidor central).
- **Antivírus pode quarentenar o `servir.ps1`** por ser PowerShell na rede.
  Se acontecer, libere o arquivo no antivírus ou copie pra local.

---

# Modelo A - Servidor central

**Quando usar:** você tem um PC que pode ficar dedicado servindo, e quer uma
URL única (`http://NOME-DO-PC:8080/`) que todos os operadores acessam pelo
navegador da rede da empresa.

## Passo 1 - Liberar o acesso pela rede (uma vez só)

> Se o uso for **só no próprio PC** (operador abre o navegador na mesma máquina),
> pode pular este passo - o servidor já funciona pelo `http://localhost:8080/`.

1. Copie a pasta inteira da calculadora para o PC que vai servir
   (ex: `C:\Calculadora`).
2. Clique com o **botão direito** em `instalar-acl.bat`.
3. Escolha **"Executar como administrador"**.
4. Aceite o aviso do Windows (UAC).
5. Vai aparecer:
   ```
   PRONTO! Agora pode fechar esta janela...
   ```

Isso faz duas coisas, de forma permanente:
- Autoriza o PowerShell a abrir a porta `8080` para a rede.
- Libera a porta `8080` no Firewall do Windows.

---

## Passo 2 - Iniciar o servidor central

Dê **duplo clique em `iniciar-servidor.bat`**.

Vai abrir uma janela preta como esta:

```
================================================================
  Calculadora de Producao - Servidor iniciado
================================================================
  Pasta servida : C:\Calculadora
  Porta         : 8080

  Acesse pelo navegador:
    http://localhost:8080/
    http://PC-PRODUCAO:8080/
    http://192.168.1.50:8080/
    http://192.168.1.51:8080/

  Para parar o servidor: pressione Ctrl+C ou feche esta janela.
================================================================
```

**Deixe essa janela aberta** enquanto o servidor estiver no ar. Cada requisição
aparece como log (útil para debug).

---

## Passo 3 - Acessar de outros PCs

Em qualquer PC da rede da empresa, abra o navegador (Chrome/Edge/Firefox) e
digite **uma das URLs verdes** que apareceram no console acima. Geralmente:

    http://NOME-DO-PC:8080/

> Dica: anote a URL em um post-it nas máquinas dos operadores, ou crie um atalho
> na área de trabalho deles. Para criar atalho:
> - Botão direito na Área de Trabalho > Novo > Atalho
> - Local: `http://NOME-DO-PC:8080/`
> - Nome: "Calculadora de Produção"

---

## Passo 4 (opcional) - Subir automaticamente com o Windows

Se você quiser que o servidor inicie **sozinho ao ligar o PC**:

1. Dê duplo clique em `iniciar-no-boot.bat`.
2. Vai aparecer:
   ```
   PRONTO! O servidor subira automaticamente no proximo boot.
   ```

Da próxima vez que o PC for ligado, o servidor sobe sozinho em janela
minimizada.

**Para desativar depois:** abra o menu Iniciar, digite `shell:startup` e Enter -
vai abrir uma pasta. Apague o atalho **"Calculadora de Produção"** de lá.

---

## Como parar o servidor

Três formas, em ordem de simplicidade:

1. **Feche a janela preta** do servidor (X no canto).
2. Clique na janela preta e pressione `Ctrl + C`.
3. Dê duplo clique em `parar-servidor.bat`.

---

## Trocando a porta

A porta padrão é a `8080`. Se ela já estiver em uso no PC (outro programa
escutando lá), edite o arquivo `iniciar-servidor.bat` e troque a linha:

```bat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servir.ps1" %*
```

para incluir a porta nova:

```bat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servir.ps1" -Port 9000
```

> Atenção: se trocar a porta, refaça o `instalar-acl.bat` editando-o antes para
> a nova porta (variável `PORT` no topo).

---

## Acesso só local (sem rede)

Se você quiser que **apenas o próprio PC** acesse (operador abre o navegador no
mesmo PC), pode pular o `instalar-acl.bat`. Edite `iniciar-servidor.bat` e
adicione `-LocalOnly`:

```bat
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servir.ps1" -LocalOnly
```

Aí o servidor só responde em `http://localhost:8080/` e não precisa de admin.

---

## Atualizando a calculadora

Quando você editar a calculadora e quiser publicar a nova versão:

1. Substitua os arquivos da pasta de produção (`index.html`, `app.js`,
   `style.css`, etc.) pelos novos.
2. **Importante:** abra o `sw.js` e incremente a versão do cache:
   ```js
   const CACHE = "calc-producao-v6";  // troque para v7, v8, etc.
   ```
   Isso garante que os navegadores dos operadores baixem a versão nova
   automaticamente.
3. Não precisa reiniciar o servidor - ele serve direto do disco.
4. Os operadores podem ter que dar `Ctrl + F5` uma vez para limpar o cache do
   navegador.

---

## Resolução de problemas

### "Acesso negado" ao iniciar
Você não rodou o `instalar-acl.bat` como administrador. Veja o **Passo 1**.

### "A porta 8080 ja esta em uso"
Outro programa está usando a porta. Para descobrir qual:
```cmd
netstat -ano | findstr :8080
```
Ou troque a porta como descrito em **Trocando a porta**.

### Outros PCs não conseguem acessar
Causas comuns:
- **Firewall do Windows** bloqueando: rode o `instalar-acl.bat` (cria a regra).
- **Firewall de antivírus** (Kaspersky, Avast, etc.) bloqueando: libere a porta
  8080 nas configurações dele.
- **Rede separada**: certifique-se de que os PCs estão na mesma rede
  (faixa `192.168.x.x` ou similar). Em hotspots de celular ou redes "guest",
  isso costuma ser bloqueado.
- **Nome do PC não resolve**: use o IP em vez do nome
  (ex: `http://192.168.1.50:8080/`).

### A janela do servidor fechou sozinha
Olhe a última linha antes do encerramento. Se aparecer "Acesso negado", é o
problema do **ACL** (Passo 1). Se aparecer "porta em uso", é conflito de porta.

### Como saber o IP do PC?
Abra o `iniciar-servidor.bat` - ele lista todos os IPs disponíveis no banner
verde. Ou no Prompt: `ipconfig`.

---

## Por dentro - como funciona

- O `servir.ps1` usa `System.Net.HttpListener` do .NET (nativo no Windows).
- Serve arquivos estáticos da própria pasta, com MIME types corretos.
- Bloqueia path traversal (`..` na URL).
- Loga cada requisição com IP de origem e status HTTP.
- O `iniciar-servidor.bat` apenas chama o PowerShell com a política de execução
  flexibilizada **só para este processo** (não altera nada permanente no
  sistema).

Como toda a aplicação é estática (HTML + CSS + JS puro, com Chart.js e XLSX
carregados de CDN), não há banco de dados, backend, dependências de runtime
ou requisitos de licença. Funciona offline (Service Worker) depois da primeira
visita.
