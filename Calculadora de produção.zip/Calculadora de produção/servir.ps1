# Servidor HTTP estatico para a Calculadora de Producao.
# Roda com PowerShell nativo do Windows - nao precisa instalar nada.
#
# Uso normal:
#   .\servir.ps1
#
# Parametros opcionais:
#   -Port 8080         (porta de escuta; padrao 8080)
#   -Root <caminho>    (pasta servida; padrao = pasta do script)
#   -LocalOnly         (escuta apenas em localhost; sem acesso pela rede)

param(
  [int]$Port = 8080,
  [string]$Root = $PSScriptRoot,
  [switch]$LocalOnly,
  [switch]$AutoPort,
  [switch]$OpenBrowser
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$mime = @{
  ".html" = "text/html; charset=utf-8"
  ".htm"  = "text/html; charset=utf-8"
  ".css"  = "text/css; charset=utf-8"
  ".js"   = "application/javascript; charset=utf-8"
  ".mjs"  = "application/javascript; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".xlsx" = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  ".xls"  = "application/vnd.ms-excel"
  ".csv"  = "text/csv; charset=utf-8"
  ".png"  = "image/png"
  ".jpg"  = "image/jpeg"
  ".jpeg" = "image/jpeg"
  ".gif"  = "image/gif"
  ".svg"  = "image/svg+xml"
  ".ico"  = "image/x-icon"
  ".webp" = "image/webp"
  ".woff" = "font/woff"
  ".woff2"= "font/woff2"
  ".ttf"  = "font/ttf"
  ".otf"  = "font/otf"
  ".txt"  = "text/plain; charset=utf-8"
  ".pdf"  = "application/pdf"
  ".map"  = "application/json; charset=utf-8"
}

function Test-PortFree {
  param([int]$P)
  try {
    $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $P)
    $l.Start()
    $l.Stop()
    return $true
  } catch {
    return $false
  }
}

function Get-LocalIPs {
  try {
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
      Where-Object {
        $_.IPAddress -notlike "127.*" -and
        $_.IPAddress -notlike "169.254.*" -and
        $_.PrefixOrigin -ne "WellKnown"
      } |
      Select-Object -ExpandProperty IPAddress
  } catch {
    @()
  }
}

function Write-Color {
  param([string]$Text, [ConsoleColor]$Color = "White", [switch]$NoNewline)
  $prev = [Console]::ForegroundColor
  [Console]::ForegroundColor = $Color
  if ($NoNewline) { [Console]::Write($Text) } else { [Console]::WriteLine($Text) }
  [Console]::ForegroundColor = $prev
}

# Resolve a pasta servida para caminho absoluto canonico, evitando path traversal.
# Suporta caminhos UNC (\\servidor\share\...) e drives mapeados (Z:\...).
$Root = (Resolve-Path -LiteralPath $Root).ProviderPath
$rootCanon = [System.IO.Path]::GetFullPath($Root)

# Se -AutoPort, tenta achar uma porta livre na faixa $Port..$Port+19.
# Util quando varios operadores rodam no mesmo PC ou a porta padrao esta ocupada.
if ($AutoPort) {
  $startPort = $Port
  $found = $false
  for ($p = $startPort; $p -le ($startPort + 19); $p++) {
    if (Test-PortFree -P $p) { $Port = $p; $found = $true; break }
  }
  if (-not $found) {
    Write-Color ""
    Write-Color "ERRO: nao encontrei porta livre entre $startPort e $($startPort + 19)." Red
    Write-Color "Feche outros programas usando essas portas ou troque com -Port." Yellow
    Read-Host "Pressione ENTER para fechar"
    exit 1
  }
}

# Quando LocalOnly, escuta apenas em localhost (nao requer URL ACL).
# Caso contrario, escuta em wildcard (acesso pela rede) - precisa de URL ACL.
$prefix = if ($LocalOnly) { "http://localhost:$Port/" } else { "http://+:$Port/" }

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
  $listener.Start()
} catch [System.Net.HttpListenerException] {
  Write-Color "" 
  Write-Color "ERRO ao iniciar o servidor:" Red
  Write-Color "  $($_.Exception.Message)" Yellow
  Write-Color ""
  if ($_.Exception.ErrorCode -eq 5 -or $_.Exception.Message -like "*Acesso negado*" -or $_.Exception.Message -like "*Access*denied*") {
    Write-Color "CAUSA: O Windows exige permissao para escutar em http://+:$Port/." Yellow
    Write-Color "SOLUCAO: clique com botao direito em 'instalar-acl.bat' e escolha" White
    Write-Color "         'Executar como administrador' (basta uma vez)." White
    Write-Color ""
    Write-Color "Alternativa: rode este script com -LocalOnly (sem acesso pela rede):" Gray
    Write-Color "  .\servir.ps1 -LocalOnly" Gray
  } elseif ($_.Exception.Message -like "*j*em uso*" -or $_.Exception.Message -like "*already in use*") {
    Write-Color "CAUSA: A porta $Port ja esta em uso por outro programa." Yellow
    Write-Color "SOLUCAO: feche o programa que esta usando, ou troque a porta:" White
    Write-Color "  .\servir.ps1 -Port 8081" Gray
  }
  Write-Color ""
  Read-Host "Pressione ENTER para fechar"
  exit 1
}

# Banner de inicializacao com URLs uteis.
$pcName = $env:COMPUTERNAME
$ips    = if ($LocalOnly) { @() } else { Get-LocalIPs }

Write-Color "" 
Write-Color "================================================================" Cyan
Write-Color "  Calculadora de Producao - Servidor iniciado" Cyan
Write-Color "================================================================" Cyan
Write-Color "  Pasta servida : $rootCanon" Gray
Write-Color "  Porta         : $Port" Gray
Write-Color ""
Write-Color "  Acesse pelo navegador:" White
  Write-Color "    http://localhost:$Port/" Green
if (-not $LocalOnly) {
  Write-Color "    http://${pcName}:$Port/" Green
  foreach ($ip in $ips) {
    Write-Color "    http://${ip}:$Port/" Green
  }
}
Write-Color ""
Write-Color "  Para parar o servidor: pressione Ctrl+C ou feche esta janela." Yellow
Write-Color "================================================================" Cyan
Write-Color ""

if ($OpenBrowser) {
  try {
    Start-Process "http://localhost:$Port/" | Out-Null
    Write-Color "Navegador aberto em http://localhost:$Port/" Gray
    Write-Color ""
  } catch {
    Write-Color "(Nao consegui abrir o navegador automaticamente; abra manualmente)" Yellow
  }
}

# Loop principal. Cada requisicao e tratada em ordem; e suficiente para uso interno.
try {
  while ($listener.IsListening) {
    $context  = $listener.GetContext()
    $request  = $context.Request
    $response = $context.Response

    try {
      $rawPath = [System.Uri]::UnescapeDataString($request.Url.AbsolutePath)
      if ([string]::IsNullOrEmpty($rawPath) -or $rawPath -eq "/") {
        $rawPath = "/index.html"
      }
      # Strip da barra inicial e normalizacao de separadores.
      $relPath = $rawPath.TrimStart('/').Replace('/', [System.IO.Path]::DirectorySeparatorChar)
      $fullPath = [System.IO.Path]::GetFullPath((Join-Path $rootCanon $relPath))

      # Protecao contra path traversal: o caminho final tem que estar dentro do Root.
      if (-not $fullPath.StartsWith($rootCanon, [System.StringComparison]::OrdinalIgnoreCase)) {
        $response.StatusCode = 403
        $msg = [System.Text.Encoding]::UTF8.GetBytes("403 - Caminho fora da pasta servida.")
        $response.ContentType = "text/plain; charset=utf-8"
        $response.ContentLength64 = $msg.Length
        $response.OutputStream.Write($msg, 0, $msg.Length)
      }
      elseif (Test-Path -LiteralPath $fullPath -PathType Container) {
        # Para diretorios, tenta servir index.html dentro deles.
        $idx = Join-Path $fullPath "index.html"
        if (Test-Path -LiteralPath $idx -PathType Leaf) {
          $fullPath = $idx
        } else {
          $response.StatusCode = 404
          $msg = [System.Text.Encoding]::UTF8.GetBytes("404 - Diretorio sem index.html.")
          $response.ContentType = "text/plain; charset=utf-8"
          $response.ContentLength64 = $msg.Length
          $response.OutputStream.Write($msg, 0, $msg.Length)
          $fullPath = $null
        }
      }
      elseif (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        $response.StatusCode = 404
        $msg = [System.Text.Encoding]::UTF8.GetBytes("404 - Arquivo nao encontrado: $rawPath")
        $response.ContentType = "text/plain; charset=utf-8"
        $response.ContentLength64 = $msg.Length
        $response.OutputStream.Write($msg, 0, $msg.Length)
        $fullPath = $null
      }

      if ($fullPath) {
        $ext = [System.IO.Path]::GetExtension($fullPath).ToLowerInvariant()
        $ctype = $mime[$ext]
        if (-not $ctype) { $ctype = "application/octet-stream" }
        $bytes = [System.IO.File]::ReadAllBytes($fullPath)
        $response.StatusCode = 200
        $response.ContentType = $ctype
        # Sem cache: garante que mudancas apareçam imediatamente. O SW da app cuida do offline.
        $response.Headers.Add("Cache-Control", "no-cache")
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
      }
    } catch {
      $response.StatusCode = 500
      $err = "500 - $($_.Exception.Message)"
      $msg = [System.Text.Encoding]::UTF8.GetBytes($err)
      $response.ContentType = "text/plain; charset=utf-8"
      $response.ContentLength64 = $msg.Length
      try { $response.OutputStream.Write($msg, 0, $msg.Length) } catch {}
      Write-Color "[ERRO] $($_.Exception.Message)" Red
    } finally {
      $now = (Get-Date).ToString("HH:mm:ss")
      $remote = $request.RemoteEndPoint.Address.ToString()
      $status = $response.StatusCode
      $color  = if ($status -ge 500) { "Red" } elseif ($status -ge 400) { "Yellow" } else { "Gray" }
      Write-Color ("[{0}] {1,-15} {2} {3} -> {4}" -f $now, $remote, $request.HttpMethod, $request.Url.AbsolutePath, $status) $color
      try { $response.Close() } catch {}
    }
  }
} finally {
  if ($listener) {
    try { $listener.Stop() } catch {}
    try { $listener.Close() } catch {}
  }
}
