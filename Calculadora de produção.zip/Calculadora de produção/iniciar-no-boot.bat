@echo off
REM Cria um atalho em "Iniciar > Inicializar" para o servidor subir
REM automaticamente quando o Windows liga. Roda em segundo plano (minimizado).
REM
REM Para desativar: Win+R -> shell:startup -> apague "Calculadora de Producao".

setlocal
cd /d "%~dp0"

set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "SHORTCUT=%STARTUP_DIR%\Calculadora de Producao.lnk"
set "TARGET=%~dp0iniciar-servidor.bat"

echo Criando atalho de inicializacao automatica...
echo Pasta de Startup: %STARTUP_DIR%

powershell.exe -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT%'); $s.TargetPath = '%TARGET%'; $s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 7; $s.IconLocation = '%SystemRoot%\System32\shell32.dll,13'; $s.Description = 'Servidor da Calculadora de Producao'; $s.Save()"

if exist "%SHORTCUT%" (
    echo.
    echo ============================================================
    echo  PRONTO! O servidor subira automaticamente no proximo boot.
    echo ============================================================
    echo.
    echo  Para DESATIVAR depois, apague o atalho em:
    echo    %SHORTCUT%
    echo  ^(ou rode "shell:startup" no menu Iniciar^)
    echo.
) else (
    echo.
    echo Falha ao criar o atalho. Tente novamente.
    echo.
)

pause
endlocal
