@echo off
REM ============================================================
REM  Cria um atalho "Calculadora de Producao" na Area de Trabalho
REM  do operador, apontando para abrir-calculadora-da-rede.bat
REM  desta mesma pasta.
REM
REM  O atalho aceita estar na rede (UNC) ou drive mapeado.
REM  Cada operador clica neste arquivo UMA VEZ - depois passa a
REM  usar o atalho da Area de Trabalho dele.
REM ============================================================

setlocal

REM pushd mapeia UNC automaticamente para um drive temporario.
pushd "%~dp0" 2>nul
if errorlevel 1 (
    echo.
    echo ERRO: nao consigo acessar a pasta:
    echo   %~dp0
    echo.
    echo Verifique se voce tem permissao de leitura no compartilhamento.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_instalar-atalho.ps1"

popd
endlocal
