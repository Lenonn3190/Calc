@echo off
REM Encerra qualquer instancia do servidor (servir.ps1) em execucao.

setlocal

echo Procurando processos do servidor...
powershell.exe -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'servir\.ps1' } | ForEach-Object { Write-Host ('Encerrando PID ' + $_.ProcessId); Stop-Process -Id $_.ProcessId -Force }"

echo.
echo Servidor encerrado.
timeout /t 2 >nul
endlocal
