@echo off
REM Instala a permissao do Windows para o servidor escutar em http://+:8080/
REM Necessario executar UMA UNICA VEZ como Administrador.
REM
REM Por que? O Windows exige permissao explicita para qualquer programa escutar
REM em portas "publicas" (acessiveis pela rede). Esta permissao e persistente -
REM uma vez configurada, o servidor sobe sem precisar de admin.

setlocal
set PORT=8080

REM Verifica se esta rodando como administrador.
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ============================================================
    echo  ATENCAO: Este arquivo precisa ser executado como ADMIN.
    echo ============================================================
    echo.
    echo  Como fazer:
    echo    1) Feche esta janela.
    echo    2) Clique com botao DIREITO em "instalar-acl.bat".
    echo    3) Escolha "Executar como administrador".
    echo.
    pause
    exit /b 1
)

echo.
echo Adicionando permissao para http://+:%PORT%/ ...
netsh http add urlacl url=http://+:%PORT%/ user=Everyone
if %errorlevel% neq 0 (
    echo.
    echo A regra pode ja existir. Para verificar, rode:
    echo   netsh http show urlacl ^| findstr %PORT%
)

echo.
echo Abrindo porta %PORT% no Firewall do Windows ...
netsh advfirewall firewall add rule name="Calculadora de Producao (porta %PORT%)" dir=in action=allow protocol=TCP localport=%PORT% >nul 2>&1
if %errorlevel% equ 0 (
    echo Regra de firewall criada.
) else (
    echo Regra de firewall pode ja existir.
)

echo.
echo ============================================================
echo  PRONTO! Agora pode fechar esta janela e dar duplo clique
echo  em "iniciar-servidor.bat".
echo ============================================================
echo.
pause
endlocal
