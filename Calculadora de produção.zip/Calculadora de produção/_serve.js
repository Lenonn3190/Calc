// Servidor HTTP local para a Calculadora de Producao.
// Esta e a versao Node.js (alternativa ao servir.ps1, util em maquinas com Node instalado).
//
// Uso:
//   node _serve.js              -> http://localhost:8080 e tambem acessivel pela rede
//   PORT=9000 node _serve.js    -> escuta na porta 9000

const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");

const PORT = Number(process.env.PORT) || 8080;
const ROOT = __dirname;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".htm":  "text/html; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".js":   "application/javascript; charset=utf-8",
  ".mjs":  "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".xls":  "application/vnd.ms-excel",
  ".csv":  "text/csv; charset=utf-8",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif":  "image/gif",
  ".svg":  "image/svg+xml",
  ".ico":  "image/x-icon",
  ".webp": "image/webp",
  ".woff": "font/woff",
  ".woff2":"font/woff2",
  ".ttf":  "font/ttf",
  ".txt":  "text/plain; charset=utf-8",
  ".pdf":  "application/pdf",
};

function localIPs() {
  const out = [];
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const a of ifaces[name] || []) {
      if (a.family === "IPv4" && !a.internal) out.push(a.address);
    }
  }
  return out;
}

const server = http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || "/").split("?")[0]);
  if (p === "/") p = "/index.html";
  const fp = path.resolve(path.join(ROOT, p));
  if (!fp.startsWith(ROOT)) {
    res.writeHead(403, { "content-type": "text/plain; charset=utf-8" });
    return res.end("403: caminho fora da pasta servida");
  }
  fs.stat(fp, (err, st) => {
    if (err) {
      res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      return res.end("404: " + p);
    }
    const finalPath = st.isDirectory() ? path.join(fp, "index.html") : fp;
    fs.readFile(finalPath, (err2, data) => {
      if (err2) {
        res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
        return res.end("404: " + p);
      }
      const ext = path.extname(finalPath).toLowerCase();
      res.writeHead(200, {
        "content-type": MIME[ext] || "application/octet-stream",
        "cache-control": "no-cache",
      });
      res.end(data);
      const now = new Date().toISOString().slice(11, 19);
      const remote = req.socket.remoteAddress || "-";
      console.log(`[${now}] ${remote.padEnd(15)} ${req.method} ${p} -> 200 (${data.length} b)`);
    });
  });
});

// Bind em 0.0.0.0 para tambem aceitar conexoes da rede.
server.listen(PORT, "0.0.0.0", () => {
  const sep = "================================================================";
  console.log("");
  console.log(sep);
  console.log("  Calculadora de Producao - Servidor iniciado (Node.js)");
  console.log(sep);
  console.log(`  Pasta servida : ${ROOT}`);
  console.log(`  Porta         : ${PORT}`);
  console.log("");
  console.log("  Acesse pelo navegador:");
  console.log(`    http://localhost:${PORT}/`);
  console.log(`    http://${os.hostname()}:${PORT}/`);
  for (const ip of localIPs()) {
    console.log(`    http://${ip}:${PORT}/`);
  }
  console.log("");
  console.log("  Para parar: pressione Ctrl+C ou feche esta janela.");
  console.log(sep);
  console.log("");
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`\nERRO: a porta ${PORT} ja esta em uso. Mude com:  PORT=8081 node _serve.js`);
  } else {
    console.error("\nERRO ao iniciar:", err.message);
  }
  process.exit(1);
});
