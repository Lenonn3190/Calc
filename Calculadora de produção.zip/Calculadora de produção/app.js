﻿const el = (id) => document.getElementById(id);

const state = {
  workbook: null,
  sheetName: null,
  rows: [],
  columns: [],
  mapping: { lot: null, qty: null, order: null, ramp: null, fixed: null },
  selectedIds: new Set(),
  charts: { main: null, lmoBalance: null, lmoFlow: null },
  lastPlan: null,
  parametros: null,
  feriados: [],
  savedScenarios: [],
  ganttView: "day",
};

function pad2(n) {
  return String(n).padStart(2, "0");
}

function fmtDateTime(d) {
  if (!d) return "—";
  const y = d.getFullYear();
  const m = pad2(d.getMonth() + 1);
  const day = pad2(d.getDate());
  const hh = pad2(d.getHours());
  const mm = pad2(d.getMinutes());
  return `${day}/${m}/${y} ${hh}:${mm}`;
}

function fmtNumber(n, digits = 0) {
  if (!Number.isFinite(n)) return "—";
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(n);
}

function fmtDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return "—";
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  if (h > 0) return `${h}h ${pad2(m)}m`;
  if (m > 0) return `${m}m ${pad2(ss)}s`;
  return `${ss}s`;
}

function parseOptionalNumber(inputValue) {
  const raw = String(inputValue ?? "").trim();
  if (raw === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function timeToMinutes(t) {
  if (!t || typeof t !== "string") return null;
  const [hh, mm] = t.split(":").map((x) => Number(x));
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  return hh * 60 + mm;
}

function minutesBetween(startMin, endMin) {
  if (!Number.isFinite(startMin) || !Number.isFinite(endMin)) return 0;
  if (endMin >= startMin) return endMin - startMin;
  return (24 * 60 - startMin) + endMin;
}

const impactLinePlugin = {
  id: "impactLine",
  afterDatasetsDraw(chart, _args, pluginOptions) {
    const lines = pluginOptions?.lines || [];
    if (!lines.length) return;
    const ca = chart.chartArea;
    if (!ca) return;
    const xScale = chart.scales?.x;
    if (!xScale) return;
    const ctx = chart.ctx;
    ctx.save();
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    for (const line of lines) {
      const idx = line?.index;
      if (!Number.isFinite(idx)) continue;
      const x = xScale.getPixelForValue(idx);
      ctx.strokeStyle = line.color || "rgba(251, 113, 133, 0.9)";
      ctx.beginPath();
      ctx.moveTo(x, ca.top);
      ctx.lineTo(x, ca.bottom);
      ctx.stroke();
      const text = String(line.label || "").trim();
      if (text) {
        ctx.setLineDash([]);
        ctx.fillStyle = line.color || "rgba(251, 113, 133, 0.9)";
        ctx.font = `700 12px ${Chart.defaults.font.family || "system-ui"}`;
        ctx.textBaseline = "top";
        ctx.fillText(text, Math.min(x + 6, ca.right - 8), ca.top + 6);
        ctx.setLineDash([6, 6]);
      }
    }
    ctx.restore();
  },
};

// Plugin para desenhar linhas verticais/horizontais em gráficos com eixo X linear (timestamps).
// Usado nos gráficos da LMO para marcar instantes importantes (início de turno, impacto, etc.).
const refLinesPlugin = {
  id: "refLines",
  afterDatasetsDraw(chart, _args, pluginOptions) {
    const vLines = pluginOptions?.vLines || [];
    const hLines = pluginOptions?.hLines || [];
    if (!vLines.length && !hLines.length) return;
    const ca = chart.chartArea;
    if (!ca) return;
    const xScale = chart.scales?.x;
    const yScale = chart.scales?.y;
    const ctx = chart.ctx;
    ctx.save();
    ctx.lineWidth = 1.5;
    if (xScale) {
      for (const line of vLines) {
        const xValue = Number(line.x);
        if (!Number.isFinite(xValue)) continue;
        if (xValue < xScale.min || xValue > xScale.max) continue;
        const x = xScale.getPixelForValue(xValue);
        ctx.strokeStyle = line.color || "rgba(251, 113, 133, 0.9)";
        ctx.setLineDash(line.dash || [6, 6]);
        ctx.beginPath();
        ctx.moveTo(x, ca.top);
        ctx.lineTo(x, ca.bottom);
        ctx.stroke();
        const text = String(line.label || "").trim();
        if (text) {
          ctx.setLineDash([]);
          ctx.fillStyle = line.color || "rgba(251, 113, 133, 0.9)";
          ctx.font = `700 11px ${Chart.defaults.font.family || "system-ui"}`;
          ctx.textBaseline = "top";
          const tx = Math.min(Math.max(x + 4, ca.left + 4), ca.right - 80);
          ctx.fillText(text, tx, ca.top + 4);
        }
      }
    }
    if (yScale) {
      for (const line of hLines) {
        const yValue = Number(line.y);
        if (!Number.isFinite(yValue)) continue;
        if (yValue < yScale.min || yValue > yScale.max) continue;
        const y = yScale.getPixelForValue(yValue);
        ctx.strokeStyle = line.color || "rgba(167, 139, 250, 0.7)";
        ctx.setLineDash(line.dash || [4, 4]);
        ctx.beginPath();
        ctx.moveTo(ca.left, y);
        ctx.lineTo(ca.right, y);
        ctx.stroke();
        const text = String(line.label || "").trim();
        if (text) {
          ctx.setLineDash([]);
          ctx.fillStyle = line.color || "rgba(167, 139, 250, 0.9)";
          ctx.font = `700 11px ${Chart.defaults.font.family || "system-ui"}`;
          ctx.textBaseline = "bottom";
          ctx.fillText(text, ca.left + 6, y - 3);
        }
      }
    }
    ctx.restore();
  },
};

function isWorkday(d) {
  const day = d.getDay();
  return day !== 0 && day !== 6;
}

function dateToYMD(d) {
  const y = d.getFullYear();
  const m = pad2(d.getMonth() + 1);
  const day = pad2(d.getDate());
  return `${y}-${m}-${day}`;
}

function isHoliday(d, feriados) {
  if (!Array.isArray(feriados) || !feriados.length) return false;
  const ymd = dateToYMD(d);
  return feriados.includes(ymd);
}

function addDays(date, days) {
  const d = new Date(date.getTime());
  d.setDate(d.getDate() + days);
  return d;
}

function shiftConfigFromUI() {
  const useShift1 = el("inUseShift1").checked;
  const useShift2 = el("inUseShift2").checked;
  const workdaysOnly = el("inWorkdays").value === "true";
  const feriados = state.feriados || [];

  const s1Start = timeToMinutes(el("inS1Start").value);
  const s1End = timeToMinutes(el("inS1End").value);
  const s2Start = timeToMinutes(el("inS2Start").value);
  const s2End = timeToMinutes(el("inS2End").value);

  const s1Kiukey1Start = timeToMinutes(el("inS1Kiukey1Start").value);
  const s1Kiukey1End = timeToMinutes(el("inS1Kiukey1End").value);
  const s1Kiukey2Start = timeToMinutes(el("inS1Kiukey2Start").value);
  const s1Kiukey2End = timeToMinutes(el("inS1Kiukey2End").value);
  const s1LunchStart = timeToMinutes(el("inS1LunchStart").value);
  const s1LunchEnd = timeToMinutes(el("inS1LunchEnd").value);

  const s2Kiukey1Start = timeToMinutes(el("inS2Kiukey1Start").value);
  const s2Kiukey1End = timeToMinutes(el("inS2Kiukey1End").value);
  const s2Kiukey2Start = timeToMinutes(el("inS2Kiukey2Start").value);
  const s2Kiukey2End = timeToMinutes(el("inS2Kiukey2End").value);
  const s2LunchStart = timeToMinutes(el("inS2LunchStart").value);
  const s2LunchEnd = timeToMinutes(el("inS2LunchEnd").value);

  return {
    useShift1,
    useShift2,
    workdaysOnly,
    feriados,
    shift1: {
      startMin: s1Start,
      endMin: s1End,
      breaks: [
        { startMin: s1Kiukey1Start, endMin: s1Kiukey1End, label: "1º KiuKey" },
        { startMin: s1LunchStart, endMin: s1LunchEnd, label: "Almoço" },
        { startMin: s1Kiukey2Start, endMin: s1Kiukey2End, label: "2º KiuKey" },
      ],
    },
    shift2: {
      startMin: s2Start,
      endMin: s2End,
      breaks: [
        { startMin: s2Kiukey1Start, endMin: s2Kiukey1End, label: "1º KiuKey" },
        { startMin: s2LunchStart, endMin: s2LunchEnd, label: "Almoço" },
        { startMin: s2Kiukey2Start, endMin: s2Kiukey2End, label: "2º KiuKey" },
      ],
    },
  };
}

function usefulSecondsPerDay(cfg) {
  const base = new Date(2000, 0, 3, 0, 0, 0, 0);
  const segments = buildProductiveSegmentsForDate(base, cfg);
  return segments.reduce((acc, s) => acc + Math.max(0, (s.end.getTime() - s.start.getTime()) / 1000), 0);
}

function buildProductiveSegmentsForDate(date, cfg) {
  const segments = [];
  const y = date.getFullYear();
  const m = date.getMonth();
  const d = date.getDate();

  const toAbsMinutes = (shiftStartMin, tMin, overnight) => {
    if (!Number.isFinite(tMin)) return null;
    if (!overnight) return tMin;
    return tMin < shiftStartMin ? tMin + 24 * 60 : tMin;
  };

  const mergeIntervals = (intervals) => {
    const sorted = intervals
      .filter((i) => Number.isFinite(i.start) && Number.isFinite(i.end) && i.end > i.start)
      .sort((a, b) => a.start - b.start);
    const merged = [];
    for (const it of sorted) {
      const last = merged[merged.length - 1];
      if (!last || it.start > last.end) merged.push({ start: it.start, end: it.end });
      else last.end = Math.max(last.end, it.end);
    }
    return merged;
  };

  const addShiftSegments = (shift, tag) => {
    const startMin = shift?.startMin;
    const endMin = shift?.endMin;
    if (!Number.isFinite(startMin) || !Number.isFinite(endMin)) return;
    const overnight = endMin <= startMin;
    const shiftStartAbs = startMin;
    const shiftEndAbs = overnight ? endMin + 24 * 60 : endMin;
    if (shiftEndAbs <= shiftStartAbs) return;

    const breaks = Array.isArray(shift?.breaks) ? shift.breaks : [];
    const breakIntervals = [];
    for (const b of breaks) {
      if (!Number.isFinite(b?.startMin) || !Number.isFinite(b?.endMin)) continue;
      const bs = toAbsMinutes(startMin, b.startMin, overnight);
      let be = toAbsMinutes(startMin, b.endMin, overnight);
      if (!Number.isFinite(bs) || !Number.isFinite(be)) continue;
      if (be <= bs) be += 24 * 60;
      const s = Math.max(shiftStartAbs, bs);
      const e = Math.min(shiftEndAbs, be);
      if (e > s) breakIntervals.push({ start: s, end: e });
    }

    const mergedBreaks = mergeIntervals(breakIntervals);
    const productive = [];
    let cursor = shiftStartAbs;
    for (const br of mergedBreaks) {
      if (br.start > cursor) productive.push({ start: cursor, end: br.start });
      cursor = Math.max(cursor, br.end);
    }
    if (cursor < shiftEndAbs) productive.push({ start: cursor, end: shiftEndAbs });

    for (const p of productive) {
      const start = new Date(y, m, d, 0, 0, 0, 0);
      start.setMinutes(start.getMinutes() + p.start);
      const end = new Date(y, m, d, 0, 0, 0, 0);
      end.setMinutes(end.getMinutes() + p.end);
      if (end.getTime() > start.getTime()) segments.push({ tag, start, end });
    }
  };

  if (cfg.useShift1) addShiftSegments(cfg.shift1, "1º turno");
  if (cfg.useShift2) addShiftSegments(cfg.shift2, "2º turno");

  segments.sort((a, b) => a.start.getTime() - b.start.getTime());
  return segments;
}

function nextWorkingWindow(fromDateTime, cfg) {
  const base = new Date(fromDateTime.getFullYear(), fromDateTime.getMonth(), fromDateTime.getDate(), 0, 0, 0, 0);
  let cursorDay = addDays(base, -1);
  for (let i = 0; i < 371; i++) {
    const day = addDays(cursorDay, i);
    if (isHoliday(day, cfg.feriados)) continue;
    if (!cfg.workdaysOnly || isWorkday(day)) {
      const segments = buildProductiveSegmentsForDate(day, cfg);
      for (const s of segments) {
        if (fromDateTime.getTime() >= s.start.getTime() && fromDateTime.getTime() < s.end.getTime()) {
          return { ...s, cursorStart: new Date(fromDateTime.getTime()) };
        }
        if (fromDateTime.getTime() < s.start.getTime()) {
          return { ...s, cursorStart: new Date(s.start.getTime()) };
        }
      }
    }
  }
  return null;
}

function clampStartToWorkingTime(startDt, cfg) {
  const w = nextWorkingWindow(startDt, cfg);
  if (!w) return startDt;
  return new Date(w.cursorStart.getTime());
}

function scheduleNetSecondsAcrossWindows(startDt, netSeconds, cfg) {
  let remainingNet = Math.max(0, netSeconds);
  let cursor = clampStartToWorkingTime(startDt, cfg);
  const allocations = [];

  for (let guard = 0; guard < 200000 && remainingNet > 0.0001; guard++) {
    const w = nextWorkingWindow(cursor, cfg);
    if (!w) break;
    const remainingThisSegment = Math.max(0, (w.end.getTime() - w.cursorStart.getTime()) / 1000);
    if (remainingThisSegment <= 0) {
      cursor = new Date(w.end.getTime());
      continue;
    }
    const takeNet = Math.min(remainingNet, remainingThisSegment);
    const segStart = new Date(w.cursorStart.getTime());
    const segEnd = new Date(w.cursorStart.getTime() + takeNet * 1000);

    allocations.push({ tag: w.tag, start: segStart, end: segEnd, netSeconds: takeNet, grossSeconds: takeNet });
    remainingNet -= takeNet;
    cursor = new Date(segEnd.getTime());
    if (cursor.getTime() >= w.end.getTime() - 1) cursor = new Date(w.end.getTime());
  }

  return { allocations, end: cursor };
}

// Soma de segundos produtivos (úteis) entre dois instantes, respeitando turnos/intervalos/feriados.
// Usado pelos gráficos de LMO para projetar consumo ao longo do tempo de calendário.
function netSecondsBetween(fromDt, toDt, cfg) {
  if (!(fromDt instanceof Date) || !(toDt instanceof Date)) return 0;
  if (toDt.getTime() <= fromDt.getTime()) return 0;
  const limit = toDt.getTime();
  let acc = 0;
  let cursor = clampStartToWorkingTime(fromDt, cfg);
  for (let guard = 0; guard < 200000; guard++) {
    if (cursor.getTime() >= limit) break;
    const w = nextWorkingWindow(cursor, cfg);
    if (!w) break;
    const winStart = w.cursorStart.getTime();
    const winEnd = w.end.getTime();
    if (winStart >= limit) break;
    const usedEnd = Math.min(winEnd, limit);
    if (usedEnd > winStart) acc += (usedEnd - winStart) / 1000;
    if (winEnd >= limit) break;
    cursor = new Date(winEnd + 1);
  }
  return acc;
}

function guessColumn(columns, candidates) {
  const normalized = columns.map((c) => String(c ?? "").trim());
  for (const cand of candidates) {
    const idx = normalized.findIndex((c) => c.toLowerCase() === cand.toLowerCase());
    if (idx >= 0) return normalized[idx];
  }
  return null;
}

function setStatus(kind, title, text) {
  const box = el("statusBox");
  box.classList.remove("error", "ok");
  if (kind === "error") box.classList.add("error");
  if (kind === "ok") box.classList.add("ok");
  box.innerHTML = `<strong>${title}</strong> ${text || ""}`.trim();
}

// Fila de toasts efêmeros. Não substitui o statusBox (que mantém histórico contextual),
// mas dá feedback imediato e visível para ações pontuais (copiar, exportar, salvar).
function showToast(kind, title, text, opts) {
  const host = el("toastHost");
  if (!host) return;
  const duration = Math.max(1500, Math.min(8000, opts?.duration ?? 3200));
  const icons = { ok: "✓", error: "!", warn: "⚠", info: "•" };
  const safeKind = ["ok", "error", "warn", "info"].includes(kind) ? kind : "info";
  const node = document.createElement("div");
  node.className = `toast toast-${safeKind}`;
  node.setAttribute("role", safeKind === "error" ? "alert" : "status");
  node.innerHTML = `
    <span class="toast-icon" aria-hidden="true">${icons[safeKind]}</span>
    <div class="toast-body">
      ${title ? `<div class="toast-title">${escapeHtml(title)}</div>` : ""}
      ${text ? `<div>${escapeHtml(text)}</div>` : ""}
    </div>
    <button class="toast-close" type="button" aria-label="Fechar">×</button>
  `;
  const close = () => {
    node.classList.add("toast-out");
    setTimeout(() => node.remove(), 200);
  };
  node.querySelector(".toast-close").addEventListener("click", close);
  host.appendChild(node);
  setTimeout(close, duration);
}

function initDates() {
  const now = new Date();
  const y = now.getFullYear();
  const m = pad2(now.getMonth() + 1);
  const d = pad2(now.getDate());
  const today = `${y}-${m}-${d}`;
  el("inStartDate").value = today;
  // Não definimos min: o usuário pode querer simular ou retomar um plano com data anterior.
  // Datas no passado são permitidas (cálculo continua válido).
  el("inStartDate").removeAttribute("min");
}

function applyParametrosToUI(p) {
  if (!p) return;
  if (Number.isFinite(p.takt)) el("inTakt").value = p.takt;
  if (Number.isFinite(p.setupMin)) el("inSetup").value = p.setupMin;
  const cpp = p.componentesPorProduto ?? p.componentsPerProduct ?? p.componentesPorPeca;
  if (Number.isFinite(cpp) && cpp > 0) el("inComponentsPerProduct").value = cpp;
  if (Number.isFinite(p.rampLossPct)) el("inRampLoss").value = p.rampLossPct;
  if (typeof p.useRampUp === "boolean") el("inUseRampUp").checked = p.useRampUp;
  if (typeof p.workdaysOnly === "boolean") el("inWorkdays").value = String(p.workdaysOnly);
  if (typeof p.useShift1 === "boolean") el("inUseShift1").checked = p.useShift1;
  if (typeof p.useShift2 === "boolean") el("inUseShift2").checked = p.useShift2;
  const s1 = p.shift1;
  if (s1) {
    if (s1.start) el("inS1Start").value = s1.start;
    if (s1.end) el("inS1End").value = s1.end;
    if (s1.kiukey1 || s1.cafe) { const k = s1.kiukey1 || s1.cafe; el("inS1Kiukey1Start").value = k.start || "09:30"; el("inS1Kiukey1End").value = k.end || "09:40"; }
    if (s1.kiukey2) { el("inS1Kiukey2Start").value = s1.kiukey2.start || "14:30"; el("inS1Kiukey2End").value = s1.kiukey2.end || "14:40"; }
    if (s1.almoco) { el("inS1LunchStart").value = s1.almoco.start || "12:00"; el("inS1LunchEnd").value = s1.almoco.end || "13:00"; }
  }
  const s2 = p.shift2;
  if (s2) {
    if (s2.start) el("inS2Start").value = s2.start;
    if (s2.end) el("inS2End").value = s2.end;
    if (s2.kiukey1 || s2.cafe) { const k = s2.kiukey1 || s2.cafe; el("inS2Kiukey1Start").value = k.start || "19:30"; el("inS2Kiukey1End").value = k.end || "19:40"; }
    if (s2.kiukey2) { el("inS2Kiukey2Start").value = s2.kiukey2.start || "00:30"; el("inS2Kiukey2End").value = s2.kiukey2.end || "00:40"; }
    if (s2.almoco) { el("inS2LunchStart").value = s2.almoco.start || "22:30"; el("inS2LunchEnd").value = s2.almoco.end || "23:00"; }
  }
  if (Array.isArray(p.feriados)) {
    state.feriados = p.feriados;
    el("feriadosInfo").textContent = p.feriados.length ? `${p.feriados.length} feriados configurados` : "Nenhum feriado (parametros.json)";
  }
  if (typeof p.useLmo === "boolean") {
    el("inUseLmo").checked = p.useLmo;
    toggleLmoUi();
  }
  if (Number.isFinite(p.lmoStock)) {
    el("inLmoStock").value = p.lmoStock;
  }
  if (Number.isFinite(p.lmoTakt) && p.lmoTakt > 0) {
    el("inLmoTakt").value = p.lmoTakt;
  }
  state.parametros = p;
  updateCapacityChip();
}

function paramsFromUI() {
  const cfg = shiftConfigFromUI();
  return {
    versao: 1,
    takt: parseFloat(el("inTakt").value) || 48,
    setupMin: parseFloat(el("inSetup").value) || 0,
    componentesPorProduto: parseFloat(el("inComponentsPerProduct").value) || 1,
    rampLossPct: Math.max(0, Number(el("inRampLoss").value || 0)),
    useRampUp: el("inUseRampUp").checked,
    workdaysOnly: el("inWorkdays").value === "true",
    useShift1: el("inUseShift1").checked,
    useShift2: el("inUseShift2").checked,
    shift1: {
      start: el("inS1Start").value || "07:00",
      end: el("inS1End").value || "16:00",
      kiukey1: { start: el("inS1Kiukey1Start").value || "09:30", end: el("inS1Kiukey1End").value || "09:40" },
      kiukey2: { start: el("inS1Kiukey2Start").value || "14:30", end: el("inS1Kiukey2End").value || "14:40" },
      almoco: { start: el("inS1LunchStart").value || "12:00", end: el("inS1LunchEnd").value || "13:00" },
    },
    shift2: {
      start: el("inS2Start").value || "16:00",
      end: el("inS2End").value || "01:00",
      kiukey1: { start: el("inS2Kiukey1Start").value || "19:30", end: el("inS2Kiukey1End").value || "19:40" },
      kiukey2: { start: el("inS2Kiukey2Start").value || "00:30", end: el("inS2Kiukey2End").value || "00:40" },
      almoco: { start: el("inS2LunchStart").value || "22:30", end: el("inS2LunchEnd").value || "23:00" },
    },
    feriados: state.feriados || [],
    useLmo: el("inUseLmo")?.checked || false,
    lmoStock: parseOptionalNumber(el("inLmoStock")?.value),
    lmoTakt: parseOptionalNumber(el("inLmoTakt")?.value),
  };
}

// Mostra/oculta os campos e gráficos da seção LMO conforme o toggle.
function toggleLmoUi() {
  const on = !!el("inUseLmo")?.checked;
  const fields = el("lmoFields");
  const fields2 = el("lmoFields2");
  const kpi = el("kpiImpactLmoBox");
  const charts = el("lmoCharts");
  if (fields) fields.hidden = !on;
  if (fields2) fields2.hidden = !on;
  if (kpi) kpi.hidden = !on;
  // Os gráficos só aparecem quando LMO ativo E há um plano calculado.
  if (charts) charts.hidden = !on || !state.lastPlan?.items?.length;
  if (on && state.lastPlan?.items?.length) {
    updateLmoCharts(state.lastPlan);
  }
}

async function loadParametrosFromJSON() {
  try {
    const res = await fetch("./parametros.json");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const p = await res.json();
    applyParametrosToUI(p);
    setStatus("ok", "Parâmetros carregados.", "Arquivo parametros.json aplicado.");
  } catch (err) {
    setStatus("error", "Não foi possível carregar parametros.json.", "Use um servidor local ou o botão Carregar JSON para selecionar o arquivo.");
    applyParametrosToUI(getDefaultParametros());
  }
}

function getDefaultParametros() {
  return {
    takt: 48,
    setupMin: 0,
    componentesPorProduto: 1,
    rampLossPct: 12,
    useRampUp: true,
    workdaysOnly: true,
    useShift1: true,
    useShift2: true,
    shift1: { start: "07:00", end: "16:00", kiukey1: { start: "09:30", end: "09:40" }, kiukey2: { start: "14:30", end: "14:40" }, almoco: { start: "12:00", end: "13:00" } },
    shift2: { start: "16:00", end: "01:00", kiukey1: { start: "19:30", end: "19:40" }, kiukey2: { start: "00:30", end: "00:40" }, almoco: { start: "22:30", end: "23:00" } },
    feriados: [],
  };
}

function saveParametrosToFile() {
  const p = paramsFromUI();
  const blob = new Blob([JSON.stringify(p, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "parametros.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  setStatus("ok", "Parâmetros exportados.", "Salve o arquivo na pasta do projeto para usar na próxima vez.");
  showToast("ok", "parametros.json baixado", "Substitua o arquivo na pasta do projeto para persistir.");
}

async function loadParametrosFromFile(file) {
  if (!file) return;
  try {
    const text = await file.text();
    const p = JSON.parse(text);
    applyParametrosToUI(p);
    setStatus("ok", "Parâmetros carregados.", "Arquivo aplicado.");
  } catch (err) {
    setStatus("error", "Arquivo inválido.", escapeHtml(err?.message || String(err)));
  }
}

function getPlanStartDateTime() {
  const d = el("inStartDate").value;
  const t = el("inStartTime").value || "07:00";
  if (!d) return new Date();
  const [yy, mm, dd] = d.split("-").map((x) => Number(x));
  const [hh, mi] = t.split(":").map((x) => Number(x));
  const dt = new Date(yy, (mm || 1) - 1, dd || 1, hh || 0, mi || 0, 0, 0);
  return dt;
}

function getParams() {
  const takt = parseFloat(el("inTakt").value) || 0;
  const setupMin = parseFloat(el("inSetup").value) || 0;
  const remainingComponents = parseOptionalNumber(el("inRemainingComponents").value);
  const remainingMotorsFirst = parseOptionalNumber(el("inRemainingMotorsFirst").value);
  const componentsPerProduct = parseOptionalNumber(el("inComponentsPerProduct").value) ?? 1;
  const useRampUp = el("inUseRampUp").checked;
  const rampLossPct = Math.max(0, Number(el("inRampLoss").value || 0));
  const useLmo = el("inUseLmo")?.checked || false;
  const lmoStock = useLmo ? parseOptionalNumber(el("inLmoStock")?.value) : null;
  // Takt da LMO: se não informado (ou inválido), usamos o takt da linha. Permite simular
  // cenários em que a LMO consome mais rápido ou mais devagar que a linha.
  const lmoTaktInput = useLmo ? parseOptionalNumber(el("inLmoTakt")?.value) : null;
  const lmoTakt = Number.isFinite(lmoTaktInput) && lmoTaktInput > 0 ? lmoTaktInput : takt;
  return { takt, setupMin, remainingComponents, remainingMotorsFirst, componentsPerProduct, useRampUp, rampLossPct, useLmo, lmoStock, lmoTakt };
}

function getSelectedRows() {
  const selected = [];
  for (const row of state.rows) {
    if (state.selectedIds.has(row.__id)) selected.push(row);
  }
  return selected;
}

function normalizeBoolean(v) {
  if (typeof v === "boolean") return v;
  const s = String(v ?? "").trim().toLowerCase();
  if (["true", "1", "sim", "yes", "y", "x"].includes(s)) return true;
  if (["false", "0", "não", "nao", "no", "n", ""].includes(s)) return false;
  return Boolean(v);
}

function parseQty(v) {
  if (typeof v === "number") return v;
  if (typeof v === "string") {
    const s = v.trim().replace(/\./g, "").replace(",", ".");
    const n = Number(s);
    return Number.isFinite(n) ? n : 0;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function applyFilterAndRender() {
  const filter = (el("inFilter").value || "").trim().toLowerCase();
  const lotCol = state.mapping.lot;
  const qtyCol = state.mapping.qty;
  const orderCol = state.mapping.order;
  const rampCol = state.mapping.ramp;
  const fixedCol = state.mapping.fixed;
  const modelCol = guessColumn(state.columns, ["Modelo", "MODELO", "Model"]);
  const motorTypeCol = guessColumn(state.columns, ["Tipo Motor", "TIPO MOTOR", "TipoMotor", "Tipo do Motor"]);
  const prodDateCol = guessColumn(state.columns, ["Data de Produção", "Data de Producao", "DATA DE PRODUÇÃO", "Data Produção", "Data Producao"]);

  const rows = state.rows
    .filter((r) => {
      if (!filter) return true;
      const hay = Object.values(r).join(" ").toLowerCase();
      return hay.includes(filter);
    })
    .slice();

  rows.sort((a, b) => {
    const ao = orderCol ? Number(a[orderCol]) : Number(a.__row);
    const bo = orderCol ? Number(b[orderCol]) : Number(b.__row);
    const an = Number.isFinite(ao) ? ao : a.__row;
    const bn = Number.isFinite(bo) ? bo : b.__row;
    return an - bn;
  });

  const body = el("tblLots");
  body.innerHTML = "";
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="9" class="helper" style="padding:12px 10px">Nenhum lote encontrado para o filtro.</td></tr>`;
    updateSelectedStats();
    return;
  }

  for (const r of rows) {
    const lot = lotCol ? String(r[lotCol] ?? "") : "";
    const model = modelCol ? String(r[modelCol] ?? "") : "";
    const motorType = motorTypeCol ? String(r[motorTypeCol] ?? "") : "";
    const prodDate = prodDateCol ? String(r[prodDateCol] ?? "") : "";
    const qty = qtyCol ? parseQty(r[qtyCol]) : 0;
    const order = orderCol ? r[orderCol] : r.__row;
    const ramp = rampCol ? normalizeBoolean(r[rampCol]) : false;
    const fixed = fixedCol ? normalizeBoolean(r[fixedCol]) : false;

    const tr = document.createElement("tr");
    const checked = state.selectedIds.has(r.__id);
    tr.innerHTML = `
      <td>
        <input class="rowcheck" type="checkbox" ${checked ? "checked" : ""} aria-label="Selecionar lote" data-id="${r.__id}">
      </td>
      <td class="mono">${escapeHtml(lot)}</td>
      <td class="mono">${escapeHtml(model)}</td>
      <td class="mono">${escapeHtml(motorType)}</td>
      <td class="mono">${escapeHtml(prodDate)}</td>
      <td class="mono">${fmtNumber(qty, 0)}</td>
      <td class="mono">${escapeHtml(String(order ?? ""))}</td>
      <td>${fixed ? `<span class="badge good">Fixado</span>` : `<span class="badge">—</span>`}</td>
      <td>${ramp ? `<span class="badge warn">Ramp</span>` : `<span class="badge">—</span>`}</td>
    `;
    body.appendChild(tr);
  }

  body.querySelectorAll(".rowcheck").forEach((cb) => {
    cb.addEventListener("change", (e) => {
      const id = e.target.getAttribute("data-id");
      if (!id) return;
      if (e.target.checked) state.selectedIds.add(id);
      else state.selectedIds.delete(id);
      updateSelectedStats();
    });
  });

  updateSelectedStats();
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function updateSelectedStats() {
  const selected = getSelectedRows();
  const qtyCol = state.mapping.qty;
  const totalQty = selected.reduce((acc, r) => acc + (qtyCol ? parseQty(r[qtyCol]) : 0), 0);

  el("badgeSelected").textContent = `${selected.length} lotes`;
  el("kpiQty").textContent = fmtNumber(totalQty, 0);
  el("kpiLots").textContent = `${selected.length} lotes selecionados`;
  el("btnRecalc").disabled = selected.length === 0 || !state.mapping.lot || !state.mapping.qty;
  el("btnExport").disabled = !state.lastPlan;
  el("btnExportXlsx").disabled = !state.lastPlan;
  el("btnPrint").disabled = !state.lastPlan;
  el("btnCopy").disabled = !state.lastPlan;
}

function updateCapacityChip() {
  const { takt } = getParams();
  const cfg = shiftConfigFromUI();
  const useful = usefulSecondsPerDay(cfg);
  const cap = takt > 0 ? useful / takt : 0;
  el("chipCapacity").textContent = fmtNumber(cap, 0);
  el("badgeUseful").textContent = `${fmtDuration(useful)}/dia`;
}

function enableMappingControls(enabled) {
  for (const id of ["inSheet", "mapLot", "mapQty", "mapOrder", "mapRamp", "mapFixed", "inFilter"]) {
    el(id).disabled = !enabled;
  }
  for (const id of ["btnAll", "btnNone", "btnFixed"]) {
    el(id).disabled = !enabled;
  }
}

function fillSelect(selectEl, options, currentValue) {
  selectEl.innerHTML = "";
  for (const opt of options) {
    const o = document.createElement("option");
    o.value = opt ?? "";
    o.textContent = opt ?? "—";
    selectEl.appendChild(o);
  }
  if (currentValue != null && options.includes(currentValue)) selectEl.value = currentValue;
}

function rebuildMappingUI() {
  const cols = state.columns.slice();
  const opts = ["", ...cols];
  fillSelect(el("mapLot"), opts, state.mapping.lot || "");
  fillSelect(el("mapQty"), opts, state.mapping.qty || "");
  fillSelect(el("mapRamp"), opts, state.mapping.ramp || "");
  fillSelect(el("mapFixed"), opts, state.mapping.fixed || "");
  fillSelect(el("mapOrder"), opts, state.mapping.order || "");
}

function applyDefaultMapping() {
  state.mapping.lot = guessColumn(state.columns, ["Lote", "LOTE", "Lotes", "Lote GPCS"]);
  state.mapping.qty = guessColumn(state.columns, ["Qtd", "QTD", "Quantidade", "QUANTIDADE"]);
  state.mapping.order = guessColumn(state.columns, ["Ordem", "ORDEM", "Sequência", "Sequencia"]);
  state.mapping.ramp = guessColumn(state.columns, ["RampUp", "Ramp Up", "RAMPUP"]);
  state.mapping.fixed = guessColumn(state.columns, ["Fixado", "FIXADO"]);
}

function extractRowsFromSheet() {
  if (!state.workbook || !state.sheetName) return;
  const ws = state.workbook.Sheets[state.sheetName];
  const json = XLSX.utils.sheet_to_json(ws, { defval: "", raw: false, header: 0 });
  const genId = () => (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") ? crypto.randomUUID() : `row-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  state.rows = json.map((r, idx) => ({ ...r, __id: genId(), __row: idx + 2 }));
  // Coleta colunas de TODAS as linhas, preservando a ordem de aparição.
  // Antes usava apenas Object.keys(json[0]), perdendo colunas vazias na 1ª linha.
  const seen = new Set();
  const cols = [];
  for (const r of json) {
    for (const k of Object.keys(r)) {
      if (!seen.has(k)) { seen.add(k); cols.push(k); }
    }
  }
  state.columns = cols;
  el("badgeRows").textContent = `${fmtNumber(state.rows.length, 0)} linhas`;
  el("badgeHint").textContent = "Selecione os lotes";
  state.selectedIds = new Set();
  state.lastPlan = null;
  el("btnExport").disabled = true;
  el("btnExportXlsx").disabled = true;
  el("btnPrint").disabled = true;
  el("btnCopy").disabled = true;
}

function loadWorkbookFromArrayBuffer(buf) {
  try {
    const wb = XLSX.read(buf, { type: "array" });
    state.workbook = wb;
    state.sheetName = wb.SheetNames?.[0] || null;
    fillSelect(el("inSheet"), wb.SheetNames || [], state.sheetName);
    el("inSheet").disabled = false;
    extractRowsFromSheet();
    applyDefaultMapping();
    rebuildMappingUI();
    enableMappingControls(true);
    applyFilterAndRender();
    setStatus("ok", "XLSX carregado.", "Selecione os lotes e clique em Calcular.");
  } catch (err) {
    setStatus("error", "Falha ao ler o arquivo.", escapeHtml(err?.message || String(err)));
  }
}

async function loadWorkbookFromFile(file) {
  if (!file) return;
  setStatus("ok", "Carregando…", "Aguarde.");
  try {
    const buf = await file.arrayBuffer();
    loadWorkbookFromArrayBuffer(buf);
  } catch (err) {
    setStatus("error", "Falha ao ler o arquivo.", escapeHtml(err?.message || String(err)));
  }
}

async function tryLoadSample() {
  const configured = state.parametros?.arquivoExemplo || "2026-01-12_JAN.NiguriMMO-Sequência de Produção.xlsx";
  // Gera variantes: original, sem acentos, com encodeURI, e o default antigo.
  const stripAccents = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const variants = new Set([
    `./${configured}`,
    `./${encodeURIComponent(configured)}`,
    `./${stripAccents(configured)}`,
    `./${encodeURIComponent(stripAccents(configured))}`,
    "./2026-01-12_JAN.NiguriMMO-Sequência de Produção.xlsx",
    "./2026-01-12_JAN.NiguriMMO-Sequencia de Producao.xlsx",
  ]);
  let lastErr = null;
  for (const url of variants) {
    try {
      const res = await fetch(url);
      if (!res.ok) { lastErr = new Error(`HTTP ${res.status}`); continue; }
      const buf = await res.arrayBuffer();
      loadWorkbookFromArrayBuffer(buf);
      return;
    } catch (err) { lastErr = err; }
  }
  setStatus(
    "error",
    "Não consegui carregar o exemplo automaticamente.",
    `Tentei ${variants.size} variações do nome. Abra a página via servidor local (não via arquivo://) ou use "Carregar XLSX".`
  );
}

function getRowField(row, colName) {
  if (!colName) return null;
  return row[colName];
}

function computeImpacts(items, cfg, params, planStart) {
  const impacts = { component: null, motorFirstLot: null, lmo: null, earliest: null };
  if (!items.length) return impacts;

  const safePlanStart = planStart || items[0].queueStart || new Date();

  const componentStock = params.remainingComponents == null ? null : Math.max(0, Number(params.remainingComponents));
  const componentsPerProduct = Math.max(0, Number(params.componentsPerProduct ?? 1));
  const componentCap = componentStock == null ? null : Math.max(0, Math.floor(componentStock / Math.max(componentsPerProduct, 1e-9)));
  const motorCapFirst = params.remainingMotorsFirst == null ? null : Math.max(0, Math.floor(params.remainingMotorsFirst));

  const totalQty = items.reduce((acc, it) => acc + (Number.isFinite(it.qty) ? it.qty : 0), 0);
  if (componentCap != null && componentCap < totalQty) {
    if (componentCap <= 0) {
      const t = clampStartToWorkingTime(safePlanStart, cfg);
      impacts.component = { time: t, itemIndex: 0, lot: items[0].lot, producedInLot: 0, missingPieces: items[0].qty, capacityPieces: componentCap, componentsPerProduct };
    } else {
      let remaining = componentCap;
      for (let idx = 0; idx < items.length; idx++) {
        const it = items[idx];
        if (remaining <= 0) {
          const t = clampStartToWorkingTime(it.queueStart, cfg);
          impacts.component = { time: t, itemIndex: idx, lot: it.lot, producedInLot: 0, missingPieces: it.qty, capacityPieces: componentCap, componentsPerProduct };
          break;
        }
        if (remaining >= it.qty) {
          remaining -= it.qty;
          continue;
        }
        const producedInLot = remaining;
        const netToImpact = it.setupSeconds + producedInLot * it.effectiveTaktSeconds;
        const { end } = scheduleNetSecondsAcrossWindows(it.queueStart, netToImpact, cfg);
        impacts.component = { time: end, itemIndex: idx, lot: it.lot, producedInLot, missingPieces: Math.max(0, it.qty - producedInLot), capacityPieces: componentCap, componentsPerProduct };
        break;
      }
    }
  }

  const first = items[0];
  if (motorCapFirst != null && first && first.originalQty == null) {
    if (motorCapFirst < first.qty) {
      if (motorCapFirst <= 0) {
        const t = clampStartToWorkingTime(first.queueStart, cfg);
        impacts.motorFirstLot = { time: t, itemIndex: 0, lot: first.lot, producedInLot: 0, missingPieces: first.qty, capacityPieces: motorCapFirst };
      } else {
        const producedInLot = motorCapFirst;
        const netToImpact = first.setupSeconds + producedInLot * first.effectiveTaktSeconds;
        const { end } = scheduleNetSecondsAcrossWindows(first.queueStart, netToImpact, cfg);
        impacts.motorFirstLot = { time: end, itemIndex: 0, lot: first.lot, producedInLot, missingPieces: Math.max(0, first.qty - producedInLot), capacityPieces: motorCapFirst };
      }
    }
  }

  // ===== Análise de impacto na LMO (próximo setor) =====
  // Regra: a LMO consome motores. A capacidade total disponível antes do impacto é:
  //   motoresTotais = estoqueLMO + (componentesEstoque ÷ componentesPorProduto)
  // O tempo até o impacto é (motoresTotais × takt_LMO) em segundos ÚTEIS contados a partir
  // do início do plano (respeita turnos, intervalos e feriados).
  //
  // Essa fórmula é equivalente a "ponto em que a MMO fica sem componente + cobertura do
  // estoque LMO" — só que sem depender do cálculo intermediário (mais robusto).
  if (params.useLmo && params.lmoStock != null && Number.isFinite(params.lmoStock)) {
    const lmoStock = Math.max(0, Number(params.lmoStock));
    const taktLmo = Math.max(1e-9, Number(params.lmoTakt ?? params.takt) || 0);

    // Capacidade adicional vinda dos componentes (se informados).
    const cpp = Math.max(1e-9, Number(params.componentsPerProduct ?? 1));
    const componentCapacity = (componentStock != null && componentStock > 0)
      ? Math.max(0, Math.floor(componentStock / cpp))
      : 0;
    const motoresTotaisDisponiveis = lmoStock + componentCapacity;
    const utilSecondsToImpact = motoresTotaisDisponiveis * taktLmo;

    const baseTime = planStart || items[0].queueStart;
    const { end: impactTime } = utilSecondsToImpact > 0
      ? scheduleNetSecondsAcrossWindows(baseTime, utilSecondsToImpact, cfg)
      : { end: clampStartToWorkingTime(baseTime, cfg) };

    // Identifica em qual lote o impacto cai. Em vez de comparar com it.start/end do calendário
    // (que pode dar problema quando lotes se sobrepõem em turnos), comparamos pela soma
    // acumulada de peças produzidas: o impacto cai no lote N em que sum(qty[0..N]) > motoresTotais.
    let impactIdx = -1;
    let producedInLot = null;
    let cumQty = 0;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (cumQty + it.qty > motoresTotaisDisponiveis) {
        impactIdx = i;
        producedInLot = Math.max(0, motoresTotaisDisponiveis - cumQty);
        break;
      }
      cumQty += it.qty;
    }

    let afterPlan = false;
    if (impactIdx === -1) {
      // motoresTotais cobre todo o plano: a LMO sobrevive até depois do fim do plano.
      impactIdx = items.length - 1;
      producedInLot = items[impactIdx].qty;
      afterPlan = true;
    }

    // Determina a causa do esgotamento (só informativo).
    const stopCause = impacts.component?.time instanceof Date ? "componente" : (afterPlan ? "fim do plano" : "componente");

    impacts.lmo = {
      time: impactTime,
      itemIndex: impactIdx,
      lot: items[impactIdx].lot,
      producedInLot,
      stockInitial: lmoStock,
      componentCapacity,
      totalMotors: motoresTotaisDisponiveis,
      taktLmo,
      utilSecondsToImpact,
      stopCause,
      afterPlan,
    };
  }

  const candidates = [impacts.component, impacts.motorFirstLot, impacts.lmo].filter((x) => x?.time instanceof Date);
  if (candidates.length) {
    candidates.sort((a, b) => a.time.getTime() - b.time.getTime());
    impacts.earliest = candidates[0];
  }

  return impacts;
}

function computePlan() {
  const params = getParams();
  const cfg = shiftConfigFromUI();
  const start = getPlanStartDateTime();
  const selected = getSelectedRows();
  const lotCol = state.mapping.lot;
  const qtyCol = state.mapping.qty;
  const orderCol = state.mapping.order;
  const rampCol = state.mapping.ramp;
  const fixedCol = state.mapping.fixed;

  if (!lotCol || !qtyCol) {
    setStatus("error", "Mapeamento incompleto.", "Defina a coluna de Lote e Quantidade.");
    return null;
  }
  if (!cfg.useShift1 && !cfg.useShift2) {
    setStatus("error", "Nenhum turno ativo.", "Ative 1º e/ou 2º turno.");
    return null;
  }
  const useful = usefulSecondsPerDay(cfg);
  if (useful <= 0) {
    setStatus("error", "Tempo útil inválido.", "Ajuste horários e intervalos de KiuKey/almoço.");
    return null;
  }
  if (!Number.isFinite(params.takt) || params.takt <= 0) {
    setStatus("error", "Takt inválido.", "Informe o takt em segundos por peça.");
    return null;
  }
  if (params.remainingComponents != null && (!Number.isFinite(params.componentsPerProduct) || params.componentsPerProduct <= 0)) {
    setStatus("error", "Parâmetro inválido.", "Informe Componentes por produto (maior que zero).");
    return null;
  }

  const ordered = selected.slice().sort((a, b) => {
    const ao = orderCol ? Number(getRowField(a, orderCol)) : Number(a.__row);
    const bo = orderCol ? Number(getRowField(b, orderCol)) : Number(b.__row);
    const an = Number.isFinite(ao) ? ao : a.__row;
    const bn = Number.isFinite(bo) ? bo : b.__row;
    return an - bn;
  });

  let cursor = start;
  const items = [];
  const shiftUse = { "1º turno": 0, "2º turno": 0 };

  for (let i = 0; i < ordered.length; i++) {
    const row = ordered[i];
    const lot = String(getRowField(row, lotCol) ?? "").trim();
    const qtyOrig = parseQty(getRowField(row, qtyCol));
    let qty = qtyOrig;
    if (i === 0 && params.remainingMotorsFirst != null) {
      const motors = Math.max(0, Math.floor(params.remainingMotorsFirst));
      qty = Math.max(0, qtyOrig - motors);
    }
    const order = orderCol ? getRowField(row, orderCol) : i + 1;
    const isRamp = rampCol ? normalizeBoolean(getRowField(row, rampCol)) : false;
    const isFixed = fixedCol ? normalizeBoolean(getRowField(row, fixedCol)) : false;

    const rampFactor = params.useRampUp && isRamp ? (1 + params.rampLossPct / 100) : 1;
    const effectiveTaktSeconds = params.takt * rampFactor;
    const setupSeconds = Math.max(0, params.setupMin) * 60 * rampFactor;
    const productionSeconds = qty * effectiveTaktSeconds;
    const netSeconds = setupSeconds + productionSeconds;

    const queueStart = new Date(cursor.getTime());
    const startItem = clampStartToWorkingTime(queueStart, cfg);
    const { allocations, end } = scheduleNetSecondsAcrossWindows(startItem, netSeconds, cfg);
    const grossSeconds = Math.max(0, (end.getTime() - queueStart.getTime()) / 1000);

    for (const a of allocations) shiftUse[a.tag] = (shiftUse[a.tag] || 0) + a.netSeconds;

    items.push({
      lot,
      qty,
      originalQty: i === 0 && qty !== qtyOrig ? qtyOrig : undefined,
      order,
      fixed: isFixed,
      ramp: isRamp,
      queueStart,
      start: startItem,
      end,
      setupSeconds,
      effectiveTaktSeconds,
      netSeconds,
      grossSeconds,
      allocations,
    });

    cursor = new Date(end.getTime());
  }

  const totalQty = items.reduce((acc, it) => acc + it.qty, 0);
  const totalNet = items.reduce((acc, it) => acc + it.netSeconds, 0);
  const totalGross = items.reduce((acc, it) => acc + it.grossSeconds, 0);
  const end = items.length ? items[items.length - 1].end : start;

  const daysNeeded = useful > 0 ? totalNet / useful : 0;
  const plan = {
    items,
    start,
    end,
    totalQty,
    totalNet,
    totalGross,
    daysNeeded,
    shiftUse,
    usefulPerDay: useful,
  };

  plan.impacts = computeImpacts(items, cfg, params, start);
  state.lastPlan = plan;
  el("btnExport").disabled = !plan.items.length;
  el("btnExportXlsx").disabled = !plan.items.length;
  el("btnPrint").disabled = !plan.items.length;
  el("btnCopy").disabled = !plan.items.length;
  setStatus("ok", "Previsão gerada.", "Ajuste takt/turnos/lotes e recalcule para comparar cenários.");
  return plan;
}

function renderPlan(plan) {
  if (!plan) return;
  el("tablePlanWrap").style.display = plan.items.length ? "block" : "none";

  el("kpiQty").textContent = fmtNumber(plan.totalQty, 0);
  el("kpiLots").textContent = `${plan.items.length} lotes no plano`;
  el("kpiNet").textContent = fmtDuration(plan.totalNet);
  el("kpiNetSub").textContent = `${fmtNumber(plan.daysNeeded, 2)} dias úteis-equivalentes`;
  el("kpiWall").textContent = fmtDuration(plan.totalGross);
  el("kpiWallSub").textContent = `Início: ${fmtDateTime(plan.start)}`;
  el("kpiEnd").textContent = fmtDateTime(plan.end);
  el("kpiEndSub").textContent = `Útil/dia: ${fmtDuration(plan.usefulPerDay)}`;

  const setImpactKpi = (boxId, valueId, subId, impact, emptyLabel) => {
    const box = el(boxId);
    box.classList.remove("good", "warn", "bad");
    if (!impact) {
      box.classList.add("good");
      el(valueId).textContent = emptyLabel;
      el(subId).textContent = "Sem impacto no plano";
      return;
    }
    box.classList.add("bad");
    el(valueId).textContent = fmtDateTime(impact.time);
    const detail = impact.producedInLot > 0
      ? `Lote ${impact.lot} · após ${fmtNumber(impact.producedInLot, 0)} peças`
      : `Lote ${impact.lot} · antes de iniciar`;
    el(subId).textContent = detail;
  };

  setImpactKpi("kpiImpactCompBox", "kpiImpactComp", "kpiImpactCompSub", plan.impacts?.component || null, "Sem falta");
  setImpactKpi("kpiImpactMotorBox", "kpiImpactMotor", "kpiImpactMotorSub", plan.impacts?.motorFirstLot || null, "Sem falta");

  // KPI LMO: só exibe se a análise estiver ativa.
  const lmoBox = el("kpiImpactLmoBox");
  const lmoActive = !!el("inUseLmo")?.checked;
  if (lmoBox) lmoBox.hidden = !lmoActive;
  if (lmoActive) {
    const lmoImpact = plan.impacts?.lmo || null;
    lmoBox.classList.remove("good", "warn", "bad", "lmo");
    if (!lmoImpact) {
      lmoBox.classList.add("good");
      el("kpiImpactLmo").textContent = "Sem falta";
      el("kpiImpactLmoSub").textContent = "Estoque LMO cobre o plano inteiro";
    } else {
      lmoBox.classList.add("lmo");
      el("kpiImpactLmo").textContent = fmtDateTime(lmoImpact.time);
      const piecesInLot = Number.isFinite(lmoImpact.producedInLot) ? lmoImpact.producedInLot : null;
      let lotDetail;
      if (lmoImpact.afterPlan) lotDetail = `Após fim do plano`;
      else if (piecesInLot == null) lotDetail = `Lote ${lmoImpact.lot}`;
      else if (piecesInLot === 0) lotDetail = `Lote ${lmoImpact.lot} · antes de iniciar`;
      else lotDetail = `Lote ${lmoImpact.lot} · após ${fmtNumber(piecesInLot, 0)} pç`;
      const compCap = Number(lmoImpact.componentCapacity || 0);
      const totalMotors = Number(lmoImpact.totalMotors || lmoImpact.stockInitial || 0);
      const composition = compCap > 0
        ? ` · ${fmtNumber(totalMotors, 0)} motores (${fmtNumber(lmoImpact.stockInitial, 0)} estoque + ${fmtNumber(compCap, 0)} de comp.)`
        : ` · ${fmtNumber(totalMotors, 0)} motores`;
      el("kpiImpactLmoSub").textContent = lotDetail + composition;
    }
  }

  const endBox = el("kpiEndBox");
  endBox.classList.remove("good", "warn", "bad");
  if (plan.daysNeeded <= 1) endBox.classList.add("good");
  else if (plan.daysNeeded <= 2.5) endBox.classList.add("warn");
  else endBox.classList.add("bad");

  el("badgeSelected").textContent = `${plan.items.length} lotes`;
  el("badgeHint").textContent = "Plano calculado";

  const tb = el("tblPlan");
  tb.innerHTML = "";
  for (let i = 0; i < plan.items.length; i++) {
    const it = plan.items[i];
    const compHit = plan.impacts?.component?.itemIndex === i;
    const motorHit = plan.impacts?.motorFirstLot?.itemIndex === i;
    const lmoHit = plan.impacts?.lmo?.itemIndex === i;
    const compMissing = compHit ? plan.impacts?.component?.missingPieces : null;
    const motorMissing = motorHit ? plan.impacts?.motorFirstLot?.missingPieces : null;
    const lmoPieces = lmoHit && Number.isFinite(plan.impacts?.lmo?.producedInLot) ? plan.impacts.lmo.producedInLot : null;
    const impactTag = (() => {
      const parts = [];
      if (compHit) parts.push(`Componente · faltam ${fmtNumber(compMissing, 0)}`);
      if (motorHit) parts.push(`Motor · faltam ${fmtNumber(motorMissing, 0)}`);
      if (lmoHit) parts.push(lmoPieces != null ? `LMO · após ${fmtNumber(lmoPieces, 0)} pç` : `LMO · imediato`);
      if (!parts.length) return `<span class="badge">—</span>`;
      const cls = lmoHit && !compHit && !motorHit ? "warn" : "bad";
      return `<span class="badge ${cls}">${escapeHtml(parts.join(" + "))}</span>`;
    })();
    const tr = document.createElement("tr");
    if (compHit || motorHit || lmoHit) tr.classList.add("row-impact");
    tr.innerHTML = `
      <td class="mono">${escapeHtml(String(it.order ?? ""))}</td>
      <td class="mono">${escapeHtml(it.lot)}</td>
      <td class="mono">${fmtNumber(it.qty, 0)}</td>
      <td class="mono">${escapeHtml(fmtDateTime(it.start))}</td>
      <td class="mono">${escapeHtml(fmtDateTime(it.end))}</td>
      <td class="mono">${escapeHtml(fmtDuration(it.netSeconds))}</td>
      <td class="mono">${escapeHtml(fmtDuration(it.grossSeconds))}</td>
      <td>${impactTag}</td>
    `;
    tb.appendChild(tr);
  }

  el("planSummary").textContent = `Término: ${fmtDateTime(plan.end)} · Total útil: ${fmtDuration(plan.totalNet)} · Total calendário: ${fmtDuration(plan.totalGross)}`;
  renderScenarios();
  renderGantt(plan);
}

function renderGantt(plan) {
  const wrap = el("ganttWrap");
  if (!plan?.items?.length) {
    wrap.style.display = "none";
    return;
  }
  wrap.style.display = "block";
  const viewMode = state.ganttView || "day";
  const start = plan.start.getTime();
  // Se o impacto LMO cair depois do fim do plano, esticamos o eixo para incluí-lo.
  const lmoTimeMs = plan.impacts?.lmo?.time instanceof Date ? plan.impacts.lmo.time.getTime() : 0;
  const end = Math.max(plan.end.getTime(), lmoTimeMs);
  const totalMs = Math.max(1, end - start);
  const ticksEl = el("ganttTicks");
  const timelineEl = el("ganttTimeline");

  const fmtTick = (d) => {
    const day = pad2(d.getDate());
    const m = pad2(d.getMonth() + 1);
    const hh = pad2(d.getHours());
    const mm = pad2(d.getMinutes());
    return viewMode === "day" ? `${day}/${m} ${hh}:${mm}` : `${day}/${m}`;
  };

  const tickCount = viewMode === "day" ? Math.min(12, Math.max(4, Math.ceil(totalMs / (3600 * 1000 * 4)))) : Math.min(14, Math.max(4, Math.ceil(totalMs / (24 * 3600 * 1000))));
  const tickStep = totalMs / (tickCount - 1);
  ticksEl.innerHTML = "";
  for (let i = 0; i < tickCount; i++) {
    const t = new Date(start + i * tickStep);
    const span = document.createElement("span");
    span.textContent = fmtTick(t);
    ticksEl.appendChild(span);
  }

  timelineEl.innerHTML = "";
  const lmoImpact = plan.impacts?.lmo || null;
  plan.items.forEach((it, idx) => {
    const compHit = plan.impacts?.component?.itemIndex === idx;
    const motorHit = plan.impacts?.motorFirstLot?.itemIndex === idx;
    const lmoHit = lmoImpact?.itemIndex === idx;
    const hasImpact = compHit || motorHit;
    const left = ((it.start.getTime() - start) / totalMs) * 100;
    const width = Math.max(2, ((it.end.getTime() - it.start.getTime()) / totalMs) * 100);
    // Mostra o rótulo dentro da barra apenas se ela for larga o bastante (>= 6% do total),
    // caso contrário fica ilegível.
    const showInsideLabel = width >= 6;
    const insideLabel = showInsideLabel
      ? `<span class="bar-label">${escapeHtml(it.lot)} · ${fmtNumber(it.qty, 0)}</span>`
      : "";
    // Classe da barra: se for LMO sem ser comp/motor, usa um visual roxo distinto.
    const barClass = hasImpact ? "impact" : (lmoHit ? "impact-lmo" : "");
    // Marcador vertical com o instante exato do impacto LMO (se cair dentro desta barra).
    let lmoMarker = "";
    if (lmoHit && lmoImpact?.time instanceof Date) {
      const tImpact = lmoImpact.time.getTime();
      const markerLeftPct = ((tImpact - start) / totalMs) * 100;
      const title = `Impacto LMO: ${fmtDateTime(lmoImpact.time)}`;
      lmoMarker = `<div class="lmo-marker" style="left:${markerLeftPct}%" title="${escapeHtml(title)}"></div>`;
    }
    const row = document.createElement("div");
    row.className = "gantt-row";
    row.innerHTML = `
      <span class="label" title="${escapeHtml(it.lot)}">${escapeHtml(it.lot.length > 20 ? it.lot.slice(0, 18) + "…" : it.lot)}</span>
      <div class="bar-track">
        <div class="bar ${barClass}" style="left:${left}%;width:${width}%" title="${escapeHtml(it.lot)}: ${fmtDateTime(it.start)} → ${fmtDateTime(it.end)} · ${fmtNumber(it.qty, 0)} peças">${insideLabel}</div>
        ${lmoMarker}
      </div>
    `;
    timelineEl.appendChild(row);
  });
}

function ensureCharts() {
  const txt = getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "rgba(255,255,255,0.92)";
  const muted = getComputedStyle(document.documentElement).getPropertyValue("--muted").trim() || "rgba(255,255,255,0.65)";
  const border = getComputedStyle(document.documentElement).getPropertyValue("--border").trim() || "rgba(255,255,255,0.12)";

  Chart.defaults.color = muted;
  Chart.defaults.borderColor = border;
  Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;

  if (!state.charts.main) {
    const canvas = el("chartMain");
    const ctx = canvas && canvas.getContext("2d");
    if (!ctx) return;
    state.charts.main = new Chart(ctx, {
      type: "bar",
      plugins: [impactLinePlugin],
      data: {
        labels: [],
        datasets: [
          {
            type: "bar",
            label: "Horas (calendário)",
            data: [],
            backgroundColor: "rgba(110, 231, 255, 0.22)",
            borderColor: "rgba(110, 231, 255, 0.55)",
            borderWidth: 1,
            borderRadius: 8,
            yAxisID: "y",
          },
          {
            type: "line",
            label: "Acumulado (h)",
            data: [],
            borderColor: "rgba(167, 139, 250, 0.85)",
            backgroundColor: "rgba(167, 139, 250, 0.2)",
            tension: 0.3,
            pointRadius: 2,
            yAxisID: "y",
          },
          {
            type: "line",
            label: "Impacto (componente)",
            data: [],
            borderColor: "rgba(251, 113, 133, 0.9)",
            backgroundColor: "rgba(251, 113, 133, 0.25)",
            tension: 0,
            showLine: false,
            pointRadius: 6,
            pointHoverRadius: 7,
            pointStyle: "triangle",
            yAxisID: "y",
          },
          {
            type: "line",
            label: "Impacto (motor 1º lote)",
            data: [],
            borderColor: "rgba(251, 191, 36, 0.95)",
            backgroundColor: "rgba(251, 191, 36, 0.25)",
            tension: 0,
            showLine: false,
            pointRadius: 6,
            pointHoverRadius: 7,
            pointStyle: "rectRot",
            yAxisID: "y",
          },
          {
            type: "line",
            label: "Impacto LMO",
            data: [],
            borderColor: "rgba(167, 139, 250, 0.95)",
            backgroundColor: "rgba(167, 139, 250, 0.3)",
            tension: 0,
            showLine: false,
            pointRadius: 7,
            pointHoverRadius: 9,
            pointStyle: "circle",
            yAxisID: "y",
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: "bottom", labels: { boxWidth: 10, usePointStyle: true } },
          impactLine: { lines: [] },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                if (ctx.raw == null) return `${ctx.dataset.label}: —`;
                const v = Number(ctx.raw);
                if (!Number.isFinite(v)) return ctx.dataset.label;
                return `${ctx.dataset.label}: ${fmtNumber(v, 2)} h`;
              },
            },
          },
        },
        scales: {
          x: { ticks: { maxRotation: 0, autoSkip: true }, grid: { display: false } },
          y: { beginAtZero: true, ticks: { callback: (v) => `${v}h` } },
        },
      },
    });
  }

  if (state.charts.main) state.charts.main.update();
}

function updateCharts(plan) {
  ensureCharts();
  if (!state.charts.main) return;
  const labels = plan.items.map((it) => it.lot.length > 18 ? `${it.lot.slice(0, 16)}…` : it.lot);
  const hours = plan.items.map((it) => it.grossSeconds / 3600);
  const cum = [];
  let acc = 0;
  for (const h of hours) {
    acc += h;
    cum.push(acc);
  }

  const compImpact = new Array(labels.length).fill(null);
  const motorImpact = new Array(labels.length).fill(null);
  const lmoImpactArr = new Array(labels.length).fill(null);
  if (plan.impacts?.component?.time instanceof Date && Number.isFinite(plan.impacts.component.itemIndex)) {
    const idx = plan.impacts.component.itemIndex;
    if (idx >= 0 && idx < labels.length) compImpact[idx] = (plan.impacts.component.time.getTime() - plan.start.getTime()) / 3600000;
  }
  if (plan.impacts?.motorFirstLot?.time instanceof Date && Number.isFinite(plan.impacts.motorFirstLot.itemIndex)) {
    const idx = plan.impacts.motorFirstLot.itemIndex;
    if (idx >= 0 && idx < labels.length) motorImpact[idx] = (plan.impacts.motorFirstLot.time.getTime() - plan.start.getTime()) / 3600000;
  }
  if (plan.impacts?.lmo?.time instanceof Date && Number.isFinite(plan.impacts.lmo.itemIndex)) {
    const idx = plan.impacts.lmo.itemIndex;
    if (idx >= 0 && idx < labels.length) lmoImpactArr[idx] = (plan.impacts.lmo.time.getTime() - plan.start.getTime()) / 3600000;
  }

  state.charts.main.data.labels = labels;
  state.charts.main.data.datasets[0].data = hours.map((h) => Number(h.toFixed(3)));
  state.charts.main.data.datasets[1].data = cum.map((h) => Number(h.toFixed(3)));
  state.charts.main.data.datasets[2].data = compImpact.map((h) => h == null ? null : Number(h.toFixed(3)));
  state.charts.main.data.datasets[3].data = motorImpact.map((h) => h == null ? null : Number(h.toFixed(3)));
  if (state.charts.main.data.datasets[4]) {
    state.charts.main.data.datasets[4].data = lmoImpactArr.map((h) => h == null ? null : Number(h.toFixed(3)));
  }

  const impactLines = [];
  const earliest = plan.impacts?.earliest || null;
  if (earliest && Number.isFinite(earliest.itemIndex)) {
    let color = "rgba(251, 113, 133, 0.9)";
    let name = "Componente";
    if (earliest === plan.impacts?.motorFirstLot) { color = "rgba(251, 191, 36, 0.95)"; name = "Motor 1º lote"; }
    else if (earliest === plan.impacts?.lmo) { color = "rgba(167, 139, 250, 0.95)"; name = "LMO"; }
    const missing = Number.isFinite(earliest.missingPieces) ? `faltam ${fmtNumber(earliest.missingPieces, 0)} peças` : "";
    const label = name === "LMO"
      ? `Impacto: ${name} · estoque zera em ${fmtDateTime(earliest.time)}`
      : `Impacto: ${name}${missing ? ` · ${missing}` : ""}`;
    impactLines.push({ index: earliest.itemIndex, color, label });
  }
  // Sempre desenhar linha do LMO mesmo que não seja o impacto mais cedo (ajuda visualizar).
  if (plan.impacts?.lmo && earliest !== plan.impacts.lmo) {
    impactLines.push({
      index: plan.impacts.lmo.itemIndex,
      color: "rgba(167, 139, 250, 0.7)",
      label: `LMO: ${fmtDateTime(plan.impacts.lmo.time)}`,
    });
  }
  state.charts.main.options.plugins.impactLine.lines = impactLines;
  state.charts.main.update();

  updateLmoCharts(plan);
}

// ===== Gráficos da análise LMO =====
// Eixo X: linear em timestamps (ms). Eixo Y: nº de motores.
// Apenas instanciados quando a análise LMO está ativada e há um plano calculado.
function ensureLmoCharts() {
  const txtVar = getComputedStyle(document.documentElement).getPropertyValue("--text").trim() || "rgba(255,255,255,0.92)";
  const mutedVar = getComputedStyle(document.documentElement).getPropertyValue("--muted").trim() || "rgba(255,255,255,0.65)";

  const tickFmt = (ms) => {
    if (!Number.isFinite(ms)) return "";
    const d = new Date(ms);
    const day = pad2(d.getDate());
    const m = pad2(d.getMonth() + 1);
    const hh = pad2(d.getHours());
    const mm = pad2(d.getMinutes());
    return `${day}/${m} ${hh}:${mm}`;
  };

  const baseScales = (yLabel) => ({
    x: {
      type: "linear",
      ticks: {
        maxRotation: 0,
        autoSkip: true,
        maxTicksLimit: 8,
        callback: (v) => tickFmt(v),
        color: mutedVar,
      },
      grid: { display: false },
    },
    y: {
      beginAtZero: true,
      title: { display: true, text: yLabel, color: mutedVar, font: { size: 11, weight: 700 } },
      ticks: { color: mutedVar, callback: (v) => fmtNumber(v, 0) },
    },
  });

  const tooltipDate = {
    callbacks: {
      title: (ctx) => {
        const x = ctx?.[0]?.parsed?.x;
        return Number.isFinite(x) ? fmtDateTime(new Date(x)) : "";
      },
      label: (ctx) => {
        const v = Number(ctx?.parsed?.y);
        if (!Number.isFinite(v)) return `${ctx.dataset.label}: —`;
        return `${ctx.dataset.label}: ${fmtNumber(v, 0)} motores`;
      },
    },
  };

  if (!state.charts.lmoBalance) {
    const canvas = el("chartLmoBalance");
    const ctx = canvas && canvas.getContext("2d");
    if (ctx) {
      state.charts.lmoBalance = new Chart(ctx, {
        type: "line",
        plugins: [refLinesPlugin],
        data: {
          datasets: [
            {
              label: "Saldo de motores",
              data: [],
              borderColor: "rgba(110, 231, 255, 0.9)",
              backgroundColor: "rgba(110, 231, 255, 0.18)",
              borderWidth: 2.5,
              tension: 0,
              fill: true,
              pointRadius: 3,
              pointHoverRadius: 5,
              pointBackgroundColor: "rgba(110, 231, 255, 1)",
            },
            {
              label: "Impacto LMO",
              data: [],
              borderColor: "rgba(251, 113, 133, 1)",
              backgroundColor: "rgba(251, 113, 133, 0.9)",
              borderWidth: 0,
              showLine: false,
              pointRadius: 7,
              pointHoverRadius: 9,
              pointStyle: "rectRot",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          parsing: false,
          interaction: { intersect: false, mode: "nearest", axis: "x" },
          plugins: {
            legend: { position: "bottom", labels: { color: txtVar, boxWidth: 10, usePointStyle: true } },
            tooltip: tooltipDate,
            refLines: { vLines: [], hLines: [] },
          },
          scales: baseScales("motores"),
        },
      });
    }
  }

  if (!state.charts.lmoFlow) {
    const canvas = el("chartLmoFlow");
    const ctx = canvas && canvas.getContext("2d");
    if (ctx) {
      state.charts.lmoFlow = new Chart(ctx, {
        type: "line",
        plugins: [refLinesPlugin],
        data: {
          datasets: [
            {
              label: "Entregue pela MMO (acum.)",
              data: [],
              borderColor: "rgba(52, 211, 153, 0.95)",
              backgroundColor: "rgba(52, 211, 153, 0.18)",
              borderWidth: 2.5,
              stepped: "after",
              tension: 0,
              fill: false,
              pointRadius: 3,
              pointHoverRadius: 5,
              pointBackgroundColor: "rgba(52, 211, 153, 1)",
            },
            {
              label: "Consumido pela LMO (acum.)",
              data: [],
              borderColor: "rgba(251, 146, 60, 0.95)",
              backgroundColor: "rgba(251, 146, 60, 0.15)",
              borderWidth: 2.5,
              tension: 0,
              fill: false,
              pointRadius: 3,
              pointHoverRadius: 5,
              pointBackgroundColor: "rgba(251, 146, 60, 1)",
            },
            {
              label: "Impacto LMO",
              data: [],
              borderColor: "rgba(251, 113, 133, 1)",
              backgroundColor: "rgba(251, 113, 133, 0.9)",
              borderWidth: 0,
              showLine: false,
              pointRadius: 7,
              pointHoverRadius: 9,
              pointStyle: "rectRot",
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          parsing: false,
          interaction: { intersect: false, mode: "nearest", axis: "x" },
          plugins: {
            legend: { position: "bottom", labels: { color: txtVar, boxWidth: 10, usePointStyle: true } },
            tooltip: tooltipDate,
            refLines: { vLines: [], hLines: [] },
          },
          scales: baseScales("motores acumulados"),
        },
      });
    }
  }
}

function updateLmoCharts(plan) {
  const wrap = el("lmoCharts");
  const lmoActive = !!el("inUseLmo")?.checked;
  const lmoImpact = plan?.impacts?.lmo || null;

  // Oculta a seção quando LMO desativada ou quando ainda não há plano.
  if (!wrap) return;
  if (!lmoActive || !plan?.items?.length) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  ensureLmoCharts();

  const cfg = shiftConfigFromUI();
  const params = getParams();
  const taktLmo = Math.max(1e-9, Number(params.lmoTakt || params.takt) || 0);
  const lmoStock = Math.max(0, Number(params.lmoStock || 0));
  const componentCapacity = Number(lmoImpact?.componentCapacity || 0);
  const totalMotors = Number(lmoImpact?.totalMotors || (lmoStock + componentCapacity));

  const planStart = plan.start;
  const planEnd = plan.end;
  const impactTime = lmoImpact?.time instanceof Date ? lmoImpact.time : null;
  // Janela do eixo X: do início do plano até o maior entre o fim do plano e o impacto.
  const xMax = Math.max(planEnd.getTime(), impactTime ? impactTime.getTime() : 0);

  // ===== Gráfico A: Saldo =====
  // Coleta de pontos (timestamp, motores no buffer). O consumo é proporcional a segundos
  // úteis decorridos desde planStart. Saturamos em 0 e em totalMotors.
  const balancePoints = [];
  const pushBal = (ts, val) => {
    const y = Math.max(0, Math.min(totalMotors, val));
    balancePoints.push({ x: ts, y });
  };
  pushBal(planStart.getTime(), totalMotors);
  // Amostra pelos eventos relevantes do plano para que o gráfico mostre claramente
  // como o estoque evolui. Para cada lote, pegamos início e fim.
  const eventTimes = new Set();
  for (const it of plan.items) {
    eventTimes.add(it.start.getTime());
    eventTimes.add(it.end.getTime());
  }
  if (impactTime) eventTimes.add(impactTime.getTime());
  const sortedEvents = Array.from(eventTimes).filter((t) => t > planStart.getTime() && t <= xMax).sort((a, b) => a - b);
  for (const ts of sortedEvents) {
    const elapsedNet = netSecondsBetween(planStart, new Date(ts), cfg);
    const consumed = elapsedNet / taktLmo;
    pushBal(ts, totalMotors - consumed);
  }
  // Garante que o último ponto seja exatamente 0 no impacto.
  if (impactTime) {
    balancePoints.push({ x: impactTime.getTime(), y: 0 });
  }

  if (state.charts.lmoBalance) {
    const ch = state.charts.lmoBalance;
    ch.data.datasets[0].data = balancePoints;
    ch.data.datasets[1].data = impactTime ? [{ x: impactTime.getTime(), y: 0 }] : [];
    const vLines = [];
    const hLines = [];
    if (impactTime) {
      vLines.push({ x: impactTime.getTime(), color: "rgba(251, 113, 133, 0.95)", label: `Impacto: ${fmtDateTime(impactTime)}`, dash: [6, 4] });
    }
    if (componentCapacity > 0 && lmoStock > 0 && lmoStock < totalMotors) {
      // Linha horizontal mostrando o "patamar" do estoque LMO puro (acima dele = vem de componentes).
      hLines.push({ y: lmoStock, color: "rgba(167, 139, 250, 0.7)", label: `Estoque LMO: ${fmtNumber(lmoStock, 0)}`, dash: [4, 4] });
    }
    ch.options.plugins.refLines.vLines = vLines;
    ch.options.plugins.refLines.hLines = hLines;
    ch.options.scales.x.min = planStart.getTime();
    ch.options.scales.x.max = xMax;
    ch.options.scales.y.suggestedMax = totalMotors;
    ch.update();
  }

  const badgeSaldo = el("lmoChartBadgeSaldo");
  if (badgeSaldo) {
    badgeSaldo.textContent = impactTime
      ? `Zera em ${fmtDateTime(impactTime)}`
      : `Saldo sobra ao fim do plano`;
    badgeSaldo.className = impactTime ? "badge bad" : "badge good";
  }

  // ===== Gráfico B: Fluxo (produção MMO × consumo LMO) =====
  // MMO: degrau crescente, LIMITADA pela capacidade de componentes (a MMO não pode produzir
  // mais motores do que componentes ela tem). Quando o limite é atingido, a curva achata e
  // permanece horizontal até o fim do eixo X.
  const componentCap = plan.impacts?.component?.capacityPieces;
  const componentImpactTime = plan.impacts?.component?.time instanceof Date
    ? plan.impacts.component.time
    : null;
  const hasCompLimit = Number.isFinite(componentCap);

  const mmoPoints = [{ x: planStart.getTime(), y: 0 }];
  let cum = 0;
  let mmoStoppedAt = null;
  for (const it of plan.items) {
    if (mmoStoppedAt) break;
    const qty = Number.isFinite(it.qty) ? it.qty : 0;
    mmoPoints.push({ x: it.start.getTime(), y: cum });
    if (hasCompLimit && cum + qty > componentCap) {
      // A MMO atinge o limite de componentes no meio (ou no início) deste lote.
      // Para no instante do impacto de componente, que já vem calculado em computeImpacts.
      const produced = Math.max(0, componentCap - cum);
      cum += produced;
      const endTs = componentImpactTime ? componentImpactTime.getTime() : it.end.getTime();
      mmoPoints.push({ x: endTs, y: cum });
      mmoStoppedAt = endTs;
    } else {
      cum += qty;
      mmoPoints.push({ x: it.end.getTime(), y: cum });
    }
  }
  // Estende a curva até o fim do eixo X mantendo o valor final (curva horizontal após a parada
  // ou após o último lote, conforme o caso).
  if (mmoPoints.length && mmoPoints[mmoPoints.length - 1].x < xMax) {
    mmoPoints.push({ x: xMax, y: cum });
  }

  // LMO: consumo linear em tempo útil. Amostra pelos mesmos eventos relevantes.
  const lmoPoints = [{ x: planStart.getTime(), y: 0 }];
  for (const ts of sortedEvents) {
    const elapsedNet = netSecondsBetween(planStart, new Date(ts), cfg);
    const consumed = Math.min(totalMotors, elapsedNet / taktLmo);
    lmoPoints.push({ x: ts, y: consumed });
  }
  if (impactTime) {
    lmoPoints.push({ x: impactTime.getTime(), y: totalMotors });
  }

  if (state.charts.lmoFlow) {
    const ch = state.charts.lmoFlow;
    ch.data.datasets[0].data = mmoPoints;
    ch.data.datasets[1].data = lmoPoints;
    ch.data.datasets[2].data = impactTime ? [{ x: impactTime.getTime(), y: totalMotors }] : [];
    const vLines = [];
    const hLines = [];
    if (totalMotors > 0) {
      hLines.push({ y: totalMotors, color: "rgba(167, 139, 250, 0.85)", label: `Teto: ${fmtNumber(totalMotors, 0)} motores`, dash: [6, 4] });
    }
    // Linha vertical âmbar marcando quando a MMO para por falta de componente (se houver).
    if (componentImpactTime) {
      vLines.push({
        x: componentImpactTime.getTime(),
        color: "rgba(251, 191, 36, 0.85)",
        label: `MMO sem componente`,
        dash: [4, 6],
      });
    }
    if (impactTime) {
      vLines.push({ x: impactTime.getTime(), color: "rgba(251, 113, 133, 0.95)", label: `Impacto LMO`, dash: [6, 4] });
    }
    ch.options.plugins.refLines.vLines = vLines;
    ch.options.plugins.refLines.hLines = hLines;
    ch.options.scales.x.min = planStart.getTime();
    ch.options.scales.x.max = xMax;
    // Eixo Y mostra de 0 até o teto (totalMotors). Acumulado da MMO não passa de componentCap,
    // então totalMotors sempre cobre. Adicionamos 5% de folga para o rótulo do teto.
    ch.options.scales.y.suggestedMax = Math.max(totalMotors, cum) * 1.05;
    ch.update();
  }

  const badgeFluxo = el("lmoChartBadgeFluxo");
  if (badgeFluxo) {
    const desc = componentCapacity > 0
      ? `${fmtNumber(totalMotors, 0)} motores = ${fmtNumber(lmoStock, 0)} estoque + ${fmtNumber(componentCapacity, 0)} de comp.`
      : `${fmtNumber(totalMotors, 0)} motores no buffer`;
    badgeFluxo.textContent = desc;
    badgeFluxo.className = "badge";
  }
}

function exportCSV(plan) {
  if (!plan?.items?.length) return;
  const rows = [];
  rows.push(["Resumo", "Valor"]);
  rows.push(["Início", fmtDateTime(plan.start)]);
  rows.push(["Término", fmtDateTime(plan.end)]);
  rows.push(["Peças", plan.totalQty]);
  rows.push(["Tempo útil", fmtDuration(plan.totalNet)]);
  rows.push(["Tempo calendário", fmtDuration(plan.totalGross)]);
  rows.push(["Dias úteis-equivalentes", fmtNumber(plan.daysNeeded, 2)]);
  rows.push(["Útil/dia", fmtDuration(plan.usefulPerDay)]);
  rows.push(["1º turno (útil)", fmtDuration(plan.shiftUse["1º turno"] || 0)]);
  rows.push(["2º turno (útil)", fmtDuration(plan.shiftUse["2º turno"] || 0)]);
  rows.push(["Impacto componente", plan.impacts?.component ? `${fmtDateTime(plan.impacts.component.time)} (faltam ${fmtNumber(plan.impacts.component.missingPieces, 0)} peças)` : "Sem impacto"]);
  rows.push(["Impacto motor 1º lote", plan.impacts?.motorFirstLot ? `${fmtDateTime(plan.impacts.motorFirstLot.time)} (faltam ${fmtNumber(plan.impacts.motorFirstLot.missingPieces, 0)} peças)` : "Sem impacto"]);
  rows.push(["Impacto LMO", plan.impacts?.lmo ? `${fmtDateTime(plan.impacts.lmo.time)} (lote ${plan.impacts.lmo.lot}${Number.isFinite(plan.impacts.lmo.producedInLot) ? `, após ${fmtNumber(plan.impacts.lmo.producedInLot, 0)} peças` : ""})` : "Sem impacto"]);
  rows.push([]);

  rows.push([
    "Ordem",
    "Lote",
    "Qtd",
    "Inicio",
    "Fim",
    "Util_s",
    "Calendario_s",
    "Util_h",
    "Calendario_h",
    "Turno1_Util_s",
    "Turno2_Util_s",
    "RampUp",
    "Fixado",
    "Impacto",
  ]);
  for (const [idx, it] of plan.items.entries()) {
    const s1Net = (it.allocations || []).filter((a) => a.tag === "1º turno").reduce((acc, a) => acc + (a.netSeconds || 0), 0);
    const s2Net = (it.allocations || []).filter((a) => a.tag === "2º turno").reduce((acc, a) => acc + (a.netSeconds || 0), 0);
    const compHit = plan.impacts?.component?.itemIndex === idx;
    const motorHit = plan.impacts?.motorFirstLot?.itemIndex === idx;
    const lmoHit = plan.impacts?.lmo?.itemIndex === idx;
    const parts = [];
    if (compHit) parts.push(`Componente (faltam ${fmtNumber(plan.impacts.component.missingPieces, 0)} pç)`);
    if (motorHit) parts.push(`Motor (faltam ${fmtNumber(plan.impacts.motorFirstLot.missingPieces, 0)} pç)`);
    if (lmoHit) {
      const piecesInLot = Number.isFinite(plan.impacts.lmo.producedInLot) ? plan.impacts.lmo.producedInLot : null;
      parts.push(piecesInLot != null ? `LMO (após ${fmtNumber(piecesInLot, 0)} pç)` : "LMO (imediato)");
    }
    const impact = parts.length ? parts.join(" + ") : "—";
    rows.push([
      it.order ?? "",
      it.lot,
      it.qty,
      fmtDateTime(it.start),
      fmtDateTime(it.end),
      Math.round(it.netSeconds),
      Math.round(it.grossSeconds),
      (it.netSeconds / 3600).toFixed(3),
      (it.grossSeconds / 3600).toFixed(3),
      Math.round(s1Net),
      Math.round(s2Net),
      it.ramp ? "Sim" : "Não",
      it.fixed ? "Sim" : "Não",
      impact,
    ]);
  }
  const csv = rows.map((r) => r.map((v) => {
    const s = String(v ?? "");
    const needs = /[;"\n\r]/.test(s);
    const safe = s.replace(/"/g, '""');
    return needs ? `"${safe}"` : safe;
  }).join(";")).join("\r\n");

  const bom = "\uFEFF";
  const blob = new Blob([bom + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const y = plan.start.getFullYear();
  const m = pad2(plan.start.getMonth() + 1);
  const d = pad2(plan.start.getDate());
  a.download = `previsao_producao_${y}-${m}-${d}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function exportXLSX(plan) {
  if (!plan?.items?.length) return;
  const wb = XLSX.utils.book_new();

  const resumo = [
    ["Resumo", "Valor"],
    ["Início", fmtDateTime(plan.start)],
    ["Término", fmtDateTime(plan.end)],
    ["Peças", plan.totalQty],
    ["Tempo útil", fmtDuration(plan.totalNet)],
    ["Tempo calendário", fmtDuration(plan.totalGross)],
    ["Dias úteis-equivalentes", Number(plan.daysNeeded.toFixed(3))],
    ["Útil/dia", fmtDuration(plan.usefulPerDay)],
    ["1º turno (útil)", fmtDuration(plan.shiftUse["1º turno"] || 0)],
    ["2º turno (útil)", fmtDuration(plan.shiftUse["2º turno"] || 0)],
    ["Impacto componente", plan.impacts?.component ? `${fmtDateTime(plan.impacts.component.time)} (faltam ${fmtNumber(plan.impacts.component.missingPieces, 0)} peças)` : "Sem impacto"],
    ["Impacto motor 1º lote", plan.impacts?.motorFirstLot ? `${fmtDateTime(plan.impacts.motorFirstLot.time)} (faltam ${fmtNumber(plan.impacts.motorFirstLot.missingPieces, 0)} peças)` : "Sem impacto"],
    ["Impacto LMO", plan.impacts?.lmo ? `${fmtDateTime(plan.impacts.lmo.time)} (lote ${plan.impacts.lmo.lot}${Number.isFinite(plan.impacts.lmo.producedInLot) ? `, após ${fmtNumber(plan.impacts.lmo.producedInLot, 0)} peças` : ""})` : "Sem impacto"],
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(resumo), "Resumo");

  const plano = [
    ["Ordem", "Lote", "Qtd", "Início", "Fim", "Útil_s", "Calendário_s", "Turno1_Útil_s", "Turno2_Útil_s", "RampUp", "Fixado", "Impacto"],
  ];
  for (const [idx, it] of plan.items.entries()) {
    const s1Net = (it.allocations || []).filter((a) => a.tag === "1º turno").reduce((acc, a) => acc + (a.netSeconds || 0), 0);
    const s2Net = (it.allocations || []).filter((a) => a.tag === "2º turno").reduce((acc, a) => acc + (a.netSeconds || 0), 0);
    const compHit = plan.impacts?.component?.itemIndex === idx;
    const motorHit = plan.impacts?.motorFirstLot?.itemIndex === idx;
    const lmoHit = plan.impacts?.lmo?.itemIndex === idx;
    const parts = [];
    if (compHit) parts.push(`Componente (faltam ${fmtNumber(plan.impacts.component.missingPieces, 0)} pç)`);
    if (motorHit) parts.push(`Motor (faltam ${fmtNumber(plan.impacts.motorFirstLot.missingPieces, 0)} pç)`);
    if (lmoHit) {
      const piecesInLot = Number.isFinite(plan.impacts.lmo.producedInLot) ? plan.impacts.lmo.producedInLot : null;
      parts.push(piecesInLot != null ? `LMO (após ${fmtNumber(piecesInLot, 0)} pç)` : "LMO (imediato)");
    }
    const impact = parts.length ? parts.join(" + ") : "—";
    plano.push([
      it.order ?? "",
      it.lot,
      it.qty,
      fmtDateTime(it.start),
      fmtDateTime(it.end),
      Math.round(it.netSeconds),
      Math.round(it.grossSeconds),
      Math.round(s1Net),
      Math.round(s2Net),
      it.ramp ? "Sim" : "Não",
      it.fixed ? "Sim" : "Não",
      impact,
    ]);
  }
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(plano), "Plano");

  const y = plan.start.getFullYear();
  const m = pad2(plan.start.getMonth() + 1);
  const d = pad2(plan.start.getDate());
  XLSX.writeFile(wb, `previsao_producao_${y}-${m}-${d}.xlsx`);
}

function loadScenariosFromStorage() {
  try {
    const raw = localStorage.getItem("calcProducao_scenarios");
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persistScenariosToStorage() {
  try {
    localStorage.setItem("calcProducao_scenarios", JSON.stringify(state.savedScenarios || []));
  } catch {}
}

function buildScenarioSnapshot() {
  const lotCol = state.mapping.lot;
  const selectedLots = lotCol
    ? getSelectedRows().map((r) => String(getRowField(r, lotCol) ?? "").trim()).filter((s) => s !== "")
    : [];
  return {
    parametros: paramsFromUI(),
    extras: {
      remainingComponents: el("inRemainingComponents").value ?? "",
      remainingMotorsFirst: el("inRemainingMotorsFirst").value ?? "",
      componentsPerProduct: el("inComponentsPerProduct").value ?? "",
      startDate: el("inStartDate").value ?? "",
      startTime: el("inStartTime").value ?? "",
      useLmo: el("inUseLmo")?.checked || false,
      lmoStock: el("inLmoStock")?.value ?? "",
      lmoTakt: el("inLmoTakt")?.value ?? "",
    },
    mapping: { ...state.mapping },
    sheetName: state.sheetName,
    selectedLots: Array.from(new Set(selectedLots)),
  };
}

function applyScenarioToUI(s) {
  if (!s) return;
  if (s.parametros) applyParametrosToUI(s.parametros);
  if (s.extras) {
    if (s.extras.remainingComponents != null) el("inRemainingComponents").value = s.extras.remainingComponents;
    if (s.extras.remainingMotorsFirst != null) el("inRemainingMotorsFirst").value = s.extras.remainingMotorsFirst;
    if (s.extras.componentsPerProduct != null) el("inComponentsPerProduct").value = s.extras.componentsPerProduct;
    if (s.extras.startDate) el("inStartDate").value = s.extras.startDate;
    if (s.extras.startTime) el("inStartTime").value = s.extras.startTime;
    if (typeof s.extras.useLmo === "boolean") {
      el("inUseLmo").checked = s.extras.useLmo;
      toggleLmoUi();
    }
    if (s.extras.lmoStock != null) el("inLmoStock").value = s.extras.lmoStock;
    if (s.extras.lmoTakt != null) el("inLmoTakt").value = s.extras.lmoTakt;
  }
  if (s.mapping) {
    state.mapping = { lot: null, qty: null, order: null, ramp: null, fixed: null, ...s.mapping };
    rebuildMappingUI();
  }

  if (state.workbook && s.sheetName && state.workbook.SheetNames?.includes(s.sheetName)) {
    state.sheetName = s.sheetName;
    el("inSheet").value = s.sheetName;
    extractRowsFromSheet();
    rebuildMappingUI();
  }

  if (state.rows.length && Array.isArray(s.selectedLots) && s.selectedLots.length) {
    const lotCol = state.mapping.lot;
    if (lotCol) {
      const want = new Set(s.selectedLots.map((x) => String(x).trim()).filter((x) => x !== ""));
      state.selectedIds = new Set();
      for (const r of state.rows) {
        const lot = String(getRowField(r, lotCol) ?? "").trim();
        if (want.has(lot)) state.selectedIds.add(r.__id);
      }
    }
  }

  updateCapacityChip();
  state.lastPlan = null;
  el("btnExport").disabled = true;
  el("btnExportXlsx").disabled = true;
  el("btnPrint").disabled = true;
  el("btnCopy").disabled = true;
  applyFilterAndRender();
  const plan = computePlan();
  if (plan) {
    renderPlan(plan);
    updateCharts(plan);
  }
  setStatus("ok", "Cenário aplicado.", `"${escapeHtml(String(s.name || "Sem nome"))}" carregado na tela.`);
}

function exportScenariosToFile() {
  const payload = { versao: 1, exportedAt: new Date().toISOString(), scenarios: state.savedScenarios || [] };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "cenarios.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function mergeScenarios(incoming) {
  const current = Array.isArray(state.savedScenarios) ? state.savedScenarios : [];
  const byId = new Map(current.filter((s) => s && s.id).map((s) => [s.id, s]));
  const genId = () => (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") ? crypto.randomUUID() : `scn-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  for (const raw of incoming) {
    if (!raw) continue;
    const id = raw.id || genId();
    if (byId.has(id)) continue;
    byId.set(id, { ...raw, id });
  }
  state.savedScenarios = Array.from(byId.values()).sort((a, b) => String(b.savedAt || "").localeCompare(String(a.savedAt || "")));
}

function attachListeners() {
  el("btnTheme").addEventListener("click", () => {
    const cur = document.documentElement.getAttribute("data-theme") || "dark";
    const next = cur === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    el("themeLabel").textContent = next === "dark" ? "Escuro" : "Claro";
    localStorage.setItem("calcProducao_theme", next);
    updateCapacityChip();
    if (state.lastPlan) updateCharts(state.lastPlan);
  });

  el("inParamsFile").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    await loadParametrosFromFile(file);
    e.target.value = "";
  });
  el("btnLoadParams").addEventListener("click", () => el("inParamsFile").click());
  el("btnSaveParams").addEventListener("click", saveParametrosToFile);

  el("inScenariosFile").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const scenarios = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.scenarios) ? parsed.scenarios : [];
      if (!Array.isArray(scenarios) || !scenarios.length) {
        setStatus("error", "Arquivo inválido.", "Não encontrei cenários no JSON.");
        e.target.value = "";
        return;
      }
      mergeScenarios(scenarios);
      persistScenariosToStorage();
      renderScenarios();
      el("panelCenarios").style.display = state.savedScenarios.length ? "block" : "none";
      setStatus("ok", "Cenários importados.", `${fmtNumber(scenarios.length, 0)} cenários adicionados.`);
      showToast("ok", "Cenários importados", `${fmtNumber(scenarios.length, 0)} cenários adicionados.`);
    } catch (err) {
      setStatus("error", "Falha ao importar.", escapeHtml(err?.message || String(err)));
      showToast("error", "Falha ao importar", err?.message || String(err));
    } finally {
      e.target.value = "";
    }
  });
  el("btnExportScenarios").addEventListener("click", exportScenariosToFile);
  el("btnImportScenarios").addEventListener("click", () => el("inScenariosFile").click());

  el("inFile").addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    await loadWorkbookFromFile(file);
  });

  el("btnLoadSample").addEventListener("click", async () => {
    await tryLoadSample();
  });

  el("inSheet").addEventListener("change", () => {
    state.sheetName = el("inSheet").value || null;
    extractRowsFromSheet();
    applyDefaultMapping();
    rebuildMappingUI();
    applyFilterAndRender();
    setStatus("ok", "Aba selecionada.", "Ajuste o mapeamento se necessário.");
  });

  const mappingHandlers = [
    ["mapLot", "lot"],
    ["mapQty", "qty"],
    ["mapOrder", "order"],
    ["mapRamp", "ramp"],
    ["mapFixed", "fixed"],
  ];
  for (const [id, key] of mappingHandlers) {
    el(id).addEventListener("change", () => {
      const v = el(id).value || null;
      state.mapping[key] = v && v !== "" ? v : null;
      applyFilterAndRender();
      state.lastPlan = null;
      el("btnExport").disabled = true;
      el("btnExportXlsx").disabled = true;
      el("btnPrint").disabled = true;
      el("btnCopy").disabled = true;
    });
  }

  let filterTimeout;
  el("inFilter").addEventListener("input", () => {
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(applyFilterAndRender, 150);
  });

  for (const id of ["inTakt", "inSetup", "inRemainingComponents", "inComponentsPerProduct", "inRemainingMotorsFirst", "inStartDate", "inStartTime", "inUseShift1", "inUseShift2", "inUseRampUp", "inS1Start", "inS1End", "inS1Kiukey1Start", "inS1Kiukey1End", "inS1Kiukey2Start", "inS1Kiukey2End", "inS1LunchStart", "inS1LunchEnd", "inS2Start", "inS2End", "inS2Kiukey1Start", "inS2Kiukey1End", "inS2Kiukey2Start", "inS2Kiukey2End", "inS2LunchStart", "inS2LunchEnd", "inRampLoss", "inWorkdays", "inUseLmo", "inLmoStock"]) {
    el(id).addEventListener("input", () => {
      updateCapacityChip();
      state.lastPlan = null;
      el("btnExport").disabled = true;
      el("btnExportXlsx").disabled = true;
      el("btnPrint").disabled = true;
      el("btnCopy").disabled = true;
    });
    el(id).addEventListener("change", () => {
      updateCapacityChip();
      state.lastPlan = null;
      el("btnExport").disabled = true;
      el("btnExportXlsx").disabled = true;
      el("btnPrint").disabled = true;
      el("btnCopy").disabled = true;
    });
  }

  // Toggle de LMO: mostra/oculta campos quando o usuário marca/desmarca.
  const lmoToggle = el("inUseLmo");
  if (lmoToggle) lmoToggle.addEventListener("change", toggleLmoUi);

  document.querySelectorAll(".panel.collapsible").forEach((panel) => {
    if (!panel.hasAttribute("data-collapsed")) panel.setAttribute("data-collapsed", "false");
    const btn = panel.querySelector("[data-collapse-btn]");
    if (btn) btn.textContent = panel.getAttribute("data-collapsed") === "true" ? "Expandir" : "Recolher";
  });
  document.querySelectorAll("[data-collapse-btn]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const panel = btn.closest(".panel.collapsible");
      if (!panel) return;
      const collapsed = panel.getAttribute("data-collapsed") === "true";
      panel.setAttribute("data-collapsed", collapsed ? "false" : "true");
      btn.textContent = collapsed ? "Recolher" : "Expandir";
    });
  });

  el("btnAll").addEventListener("click", () => {
    for (const r of state.rows) state.selectedIds.add(r.__id);
    applyFilterAndRender();
  });
  el("btnNone").addEventListener("click", () => {
    state.selectedIds = new Set();
    applyFilterAndRender();
  });
  el("btnFixed").addEventListener("click", () => {
    const fixedCol = state.mapping.fixed;
    state.selectedIds = new Set();
    if (fixedCol) {
      for (const r of state.rows) {
        if (normalizeBoolean(r[fixedCol])) state.selectedIds.add(r.__id);
      }
    }
    applyFilterAndRender();
  });

  el("btnRecalc").addEventListener("click", () => {
    const plan = computePlan();
    if (!plan) return;
    renderPlan(plan);
    updateCharts(plan);
    const impactMsg = plan.impacts?.earliest
      ? `Impacto previsto em ${fmtDateTime(plan.impacts.earliest.time)}`
      : `Término: ${fmtDateTime(plan.end)}`;
    showToast(plan.impacts?.earliest ? "warn" : "ok", "Previsão pronta", impactMsg);
  });

  el("btnExport").addEventListener("click", () => {
    exportCSV(state.lastPlan);
    if (state.lastPlan?.items?.length) showToast("ok", "CSV exportado", `${state.lastPlan.items.length} lotes baixados.`);
  });
  el("btnExportXlsx").addEventListener("click", () => {
    exportXLSX(state.lastPlan);
    if (state.lastPlan?.items?.length) showToast("ok", "XLSX exportado", `${state.lastPlan.items.length} lotes baixados.`);
  });

  el("btnPrint").addEventListener("click", () => {
    if (state.lastPlan) window.print();
  });

  el("btnCopy").addEventListener("click", async () => {
    if (!state.lastPlan?.items?.length) return;
    const lines = ["Ordem\tLote\tQtd\tInício\tFim\tÚtil\tCalendário\tImpacto"];
    state.lastPlan.items.forEach((it, idx) => {
      const compHit = state.lastPlan.impacts?.component?.itemIndex === idx;
      const motorHit = state.lastPlan.impacts?.motorFirstLot?.itemIndex === idx;
      const lmoHit = state.lastPlan.impacts?.lmo?.itemIndex === idx;
      const tags = [];
      if (compHit) tags.push("Componente");
      if (motorHit) tags.push("Motor");
      if (lmoHit) tags.push("LMO");
      const impact = tags.length ? tags.join("+") : "—";
      lines.push([it.order, it.lot, it.qty, fmtDateTime(it.start), fmtDateTime(it.end), fmtDuration(it.netSeconds), fmtDuration(it.grossSeconds), impact].join("\t"));
    });
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setStatus("ok", "Plano copiado.", "Cole no Excel ou em outro editor.");
      showToast("ok", "Copiado!", `${state.lastPlan.items.length} lotes na área de transferência.`);
    } catch (err) {
      setStatus("error", "Não foi possível copiar.", "Seu navegador pode bloquear o acesso à área de transferência.");
      showToast("error", "Falha ao copiar", "Permissão de área de transferência bloqueada.");
    }
  });

  el("inStartDate").addEventListener("change", () => {
    const v = el("inStartDate").value;
    if (v) localStorage.setItem("calcProducao_startDate", v);
  });

  const ganttDay = el("ganttViewDay");
  const ganttWeek = el("ganttViewWeek");
  if (ganttDay) ganttDay.addEventListener("click", () => {
    state.ganttView = "day";
    ganttDay.classList.add("active");
    if (ganttWeek) ganttWeek.classList.remove("active");
    if (state.lastPlan) renderGantt(state.lastPlan);
  });
  if (ganttWeek) ganttWeek.addEventListener("click", () => {
    state.ganttView = "week";
    ganttWeek.classList.add("active");
    if (ganttDay) ganttDay.classList.remove("active");
    if (state.lastPlan) renderGantt(state.lastPlan);
  });

  el("btnSaveScenario").addEventListener("click", () => {
    if (!state.lastPlan?.items?.length) return;
    const name = prompt("Nome do cenário:", `Cenário ${state.savedScenarios.length + 1}`);
    if (!name || !name.trim()) return;
    const notes = prompt("Observações (opcional):", "") ?? "";
    const genId = () => (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") ? crypto.randomUUID() : `scn-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const snapshot = buildScenarioSnapshot();
    const savedAt = new Date().toISOString();
    state.savedScenarios.unshift({
      id: genId(),
      name: name.trim(),
      notes: String(notes || ""),
      savedAt,
      end: state.lastPlan.end.getTime(),
      totalQty: state.lastPlan.totalQty,
      daysNeeded: state.lastPlan.daysNeeded,
      totalNet: state.lastPlan.totalNet,
      totalGross: state.lastPlan.totalGross,
      shiftUse: state.lastPlan.shiftUse,
      impacts: state.lastPlan.impacts || null,
      snapshot,
    });
    persistScenariosToStorage();
    renderScenarios();
    el("panelCenarios").style.display = "block";
    setStatus("ok", "Cenário salvo.", `"${name.trim()}" adicionado para comparação.`);
    showToast("ok", "Cenário salvo", `"${name.trim()}" guardado.`);
  });

  el("btnClearScenarios").addEventListener("click", () => {
    state.savedScenarios = [];
    persistScenariosToStorage();
    renderScenarios();
    el("panelCenarios").style.display = state.savedScenarios.length ? "block" : "none";
    setStatus("ok", "Cenários limpos.", "");
  });

  el("tblScenarios").addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-scn-action]");
    if (!btn) return;
    const action = btn.getAttribute("data-scn-action");
    const id = btn.getAttribute("data-scn-id");
    if (!id) return;
    const scenario = (state.savedScenarios || []).find((s) => String(s.id) === String(id));
    if (!scenario) return;

    if (action === "apply") {
      if (!scenario.snapshot) {
        setStatus("error", "Cenário incompleto.", "Este cenário não tem snapshot para aplicar.");
        return;
      }
      applyScenarioToUI({ name: scenario.name, ...scenario.snapshot });
      return;
    }
    if (action === "download") {
      const payload = { versao: 1, exportedAt: new Date().toISOString(), scenarios: [scenario] };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `cenario_${String(scenario.name || "sem_nome").replace(/[^\w\-]+/g, "_")}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      return;
    }
    if (action === "delete") {
      state.savedScenarios = (state.savedScenarios || []).filter((s) => String(s.id) !== String(id));
      persistScenariosToStorage();
      renderScenarios();
      el("panelCenarios").style.display = state.savedScenarios.length ? "block" : "none";
      setStatus("ok", "Cenário removido.", "");
    }
  });
}

function renderScenarios() {
  const tb = el("tblScenarios");
  el("badgeScenarios").textContent = `${state.savedScenarios.length} cenários`;
  el("btnSaveScenario").disabled = !state.lastPlan?.items?.length;
  if (!state.savedScenarios.length) {
    tb.innerHTML = "<tr><td colspan='8' class='helper' style='padding:12px'>Nenhum cenário salvo. Calcule um plano e clique em Salvar cenário.</td></tr>";
    return;
  }
  tb.innerHTML = "";
  state.savedScenarios.forEach((s) => {
    const tr = document.createElement("tr");
    const name = String(s.name || "Sem nome");
    const savedAt = s.savedAt ? fmtDateTime(new Date(s.savedAt)) : "—";
    const notes = String(s.notes || "");
    const notesShort = notes.length > 32 ? notes.slice(0, 30) + "…" : notes || "—";
    const end = Number.isFinite(Number(s.end)) ? fmtDateTime(new Date(Number(s.end))) : "—";
    tr.innerHTML = `
      <td class="mono">${escapeHtml(name)}</td>
      <td class="mono">${escapeHtml(savedAt)}</td>
      <td title="${escapeHtml(notes)}">${escapeHtml(notesShort)}</td>
      <td class="mono">${escapeHtml(end)}</td>
      <td class="mono">${fmtNumber(s.totalQty, 0)}</td>
      <td class="mono">${fmtNumber(s.daysNeeded, 2)}</td>
      <td class="mono">${escapeHtml(fmtDuration(s.totalNet))}</td>
      <td>
        <div class="pill-row" style="justify-content:flex-end; gap:8px">
          <button class="btn mini" type="button" data-scn-action="apply" data-scn-id="${escapeHtml(String(s.id || ""))}">Aplicar</button>
          <button class="btn mini" type="button" data-scn-action="download" data-scn-id="${escapeHtml(String(s.id || ""))}">Baixar</button>
          <button class="btn mini" type="button" data-scn-action="delete" data-scn-id="${escapeHtml(String(s.id || ""))}">Excluir</button>
        </div>
      </td>
    `;
    tb.appendChild(tr);
  });
}

function init() {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
  let deferredPrompt;
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const btn = el("btnInstall");
    if (btn) btn.style.display = "inline-flex";
  });
  const btnInstall = el("btnInstall");
  if (btnInstall) btnInstall.addEventListener("click", async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted" && btnInstall) btnInstall.style.display = "none";
    deferredPrompt = null;
  });
  const savedTheme = localStorage.getItem("calcProducao_theme");
  const prefersLight = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
  const theme = savedTheme || (prefersLight ? "light" : "dark");
  document.documentElement.setAttribute("data-theme", theme);
  el("themeLabel").textContent = theme === "dark" ? "Escuro" : "Claro";
  enableMappingControls(false);
  toggleLmoUi();
  initDates();
  loadParametrosFromJSON().then(() => {
    const savedStart = localStorage.getItem("calcProducao_startDate");
    if (savedStart) el("inStartDate").value = savedStart;
  });
  state.savedScenarios = loadScenariosFromStorage();
  renderScenarios();
  el("panelCenarios").style.display = state.savedScenarios.length ? "block" : "none";
  updateCapacityChip();
  attachListeners();
  ensureCharts();
}

init();
