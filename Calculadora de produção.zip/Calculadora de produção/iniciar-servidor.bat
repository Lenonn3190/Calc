@echo off
REM Inicia o servidor da Calculadora de Producao usando PowerShell nativo.
REM Basta dar duplo clique neste arquivo.

setlocal
cd /d "%~dp0"

REM ExecutionPolicy Bypass apenas neste processo - nao altera politicas do sistema.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servir.ps1" %*

REM Se cair aqui, o servidor terminou ou houve erro. Mantem a janela aberta.
echo.
echo Servidor encerrado.
pause
endlocal
