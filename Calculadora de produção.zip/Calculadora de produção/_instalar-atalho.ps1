# Cria o atalho "Calculadora de Producao" na Area de Trabalho do operador,
# apontando para o abrir-calculadora-da-rede.bat desta pasta.
#
# Tambem gera o arquivo icone.ico (uma unica vez por pasta) com o logo do app.
#
# Uso normal: chamado por criar-atalho-na-area-de-trabalho.bat.
# Pode ser executado direto tambem:
#   powershell -ExecutionPolicy Bypass -File _instalar-atalho.ps1

param(
  [string]$Root = $PSScriptRoot,
  [string]$Nome = "Calculadora de Producao",
  [string]$AlvoBat = "abrir-calculadora-da-rede.bat"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$Root = (Resolve-Path -LiteralPath $Root).ProviderPath

$alvoFullPath = Join-Path $Root $AlvoBat
if (-not (Test-Path -LiteralPath $alvoFullPath -PathType Leaf)) {
  Write-Host ""
  Write-Host "ERRO: nao encontrei o arquivo $AlvoBat em:" -ForegroundColor Red
  Write-Host "  $Root" -ForegroundColor Yellow
  Write-Host ""
  Write-Host "Verifique se esta rodando este script a partir da pasta da calculadora." -ForegroundColor Yellow
  Read-Host "Pressione ENTER para fechar"
  exit 1
}

# ---------- Geracao do icone.ico (idempotente) ----------
$icoPath = Join-Path $Root "icone.ico"
$icoExiste = Test-Path -LiteralPath $icoPath -PathType Leaf

if (-not $icoExiste) {
  Write-Host "Gerando icone.ico com identidade visual da calculadora..." -ForegroundColor Gray
  try {
    Add-Type -AssemblyName System.Drawing

    # Cria o desenho num bitmap 256x256 (alta resolucao); o Windows reescala para todos os tamanhos.
    $bmp = New-Object System.Drawing.Bitmap(256, 256)
    $g   = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic

    # Fundo: gradient escuro (mesmo tom do app).
    $rect = New-Object System.Drawing.Rectangle(0, 0, 256, 256)
    $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
      $rect,
      [System.Drawing.Color]::FromArgb(255, 11, 18, 32),
      [System.Drawing.Color]::FromArgb(255, 28, 38, 64),
      90.0)
    $g.FillRectangle($bgBrush, $rect)
    $bgBrush.Dispose()

    # Cantos arredondados: aplicamos uma mascara.
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $radius = 40
    $path.AddArc(0, 0, $radius*2, $radius*2, 180, 90)
    $path.AddArc(256 - $radius*2, 0, $radius*2, $radius*2, 270, 90)
    $path.AddArc(256 - $radius*2, 256 - $radius*2, $radius*2, $radius*2, 0, 90)
    $path.AddArc(0, 256 - $radius*2, $radius*2, $radius*2, 90, 90)
    $path.CloseFigure()

    # 3 barras (logo do app, cyan).
    $barColor = [System.Drawing.Color]::FromArgb(255, 110, 231, 255)
    $barBrush = New-Object System.Drawing.SolidBrush($barColor)
    # Cada barra: rect com cantos arredondados.
    function Add-RoundedRect($path, $x, $y, $w, $h, $r) {
      $path.AddArc($x, $y, $r*2, $r*2, 180, 90)
      $path.AddArc($x + $w - $r*2, $y, $r*2, $r*2, 270, 90)
      $path.AddArc($x + $w - $r*2, $y + $h - $r*2, $r*2, $r*2, 0, 90)
      $path.AddArc($x, $y + $h - $r*2, $r*2, $r*2, 90, 90)
      $path.CloseFigure()
    }
    $bars = New-Object System.Drawing.Drawing2D.GraphicsPath
    Add-RoundedRect $bars  50  72  44 128 10
    Add-RoundedRect $bars 106  48  44 152 10
    Add-RoundedRect $bars 162 100  44 100 10
    $g.FillPath($barBrush, $bars)
    $bars.Dispose()
    $barBrush.Dispose()

    $g.Dispose()

    # Salva o bitmap como PNG em memoria e monta um ICO com PNG embedded.
    # Esse formato (Vista+) preserva 100% das cores e canal alfa, ao contrario do
    # Icon.FromHandle(GetHicon) que cai no formato XOR/AND antigo e dessatura cores.
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $pngBytes = $ms.ToArray()
    $ms.Close()
    $bmp.Dispose()

    $fs = New-Object System.IO.FileStream($icoPath, [System.IO.FileMode]::Create)
    $bw = New-Object System.IO.BinaryWriter($fs)
    # ICONDIR (6 bytes)
    $bw.Write([UInt16]0)                  # Reserved
    $bw.Write([UInt16]1)                  # Type: 1 = ICO
    $bw.Write([UInt16]1)                  # Count: 1 imagem
    # ICONDIRENTRY (16 bytes)
    $bw.Write([Byte]0)                    # Width: 0 = 256
    $bw.Write([Byte]0)                    # Height: 0 = 256
    $bw.Write([Byte]0)                    # ColorCount: 0 (>=256)
    $bw.Write([Byte]0)                    # Reserved
    $bw.Write([UInt16]1)                  # Planes
    $bw.Write([UInt16]32)                 # BitCount: 32 bpp
    $bw.Write([UInt32]$pngBytes.Length)   # BytesInRes
    $bw.Write([UInt32]22)                 # ImageOffset (6 + 16)
    # PNG data
    $bw.Write($pngBytes)
    $bw.Close()
    $fs.Close()

    Write-Host "  -> $icoPath" -ForegroundColor Green
  } catch {
    Write-Host ("Falha ao gerar o icone (vou usar o icone padrao do sistema): " + $_.Exception.Message) -ForegroundColor Yellow
    $icoPath = $null
  }
} else {
  Write-Host "icone.ico ja existe nesta pasta (reutilizando)." -ForegroundColor Gray
}

# ---------- Criacao do atalho na Area de Trabalho ----------
$desktop = [Environment]::GetFolderPath("Desktop")
$atalhoPath = Join-Path $desktop "$Nome.lnk"

Write-Host ""
Write-Host "Criando atalho na sua Area de Trabalho..." -ForegroundColor Gray
Write-Host "  Local : $atalhoPath" -ForegroundColor Gray
Write-Host "  Aponta para : $alvoFullPath" -ForegroundColor Gray

$ws = New-Object -ComObject WScript.Shell
$s  = $ws.CreateShortcut($atalhoPath)
$s.TargetPath       = $alvoFullPath
$s.WorkingDirectory = $Root
$s.WindowStyle      = 1  # janela normal (vejam o servidor subindo)
$s.Description      = "Abrir a Calculadora de Producao"
if ($icoPath -and (Test-Path -LiteralPath $icoPath -PathType Leaf)) {
  $s.IconLocation = "$icoPath,0"
} else {
  # Fallback: icone moderno do Windows.
  $s.IconLocation = "$env:SystemRoot\System32\imageres.dll,76"
}
$s.Save()

if (Test-Path -LiteralPath $atalhoPath -PathType Leaf) {
  Write-Host ""
  Write-Host "============================================================" -ForegroundColor Cyan
  Write-Host "  PRONTO! Atalho criado na sua Area de Trabalho." -ForegroundColor Green
  Write-Host "============================================================" -ForegroundColor Cyan
  Write-Host "  Nome do atalho: $Nome" -ForegroundColor White
  Write-Host ""
  Write-Host "  Agora basta dar duplo clique no atalho da Area de" -ForegroundColor White
  Write-Host "  Trabalho para abrir a calculadora." -ForegroundColor White
  Write-Host "============================================================" -ForegroundColor Cyan
  Write-Host ""
} else {
  Write-Host ""
  Write-Host "ERRO: nao consegui criar o atalho." -ForegroundColor Red
  Write-Host ""
}

Read-Host "Pressione ENTER para fechar"
