@echo off
REM ============================================================
REM  Abrir Calculadora de Producao a partir de uma pasta de rede
REM ============================================================
REM
REM Como funciona:
REM   - Voce coloca a pasta da calculadora num compartilhamento
REM     (ex: \\servidor\calculadora ou Z:\calculadora).
REM   - Cada operador da duplo clique NESTE arquivo (da pasta de rede).
REM   - Um servidor leve sobe no PC do operador, lendo os arquivos
REM     da pasta de rede, e abre o navegador automaticamente.
REM
REM Nao precisa instalar nada. Nao precisa de admin.
REM Cada operador roda independente no proprio PC (porta automatica).
REM
REM Para encerrar: feche esta janela (ou o navegador, e depois esta janela).

setlocal

REM A pasta deste BAT funciona para tanto UNC (\\servidor\share)
REM como para drive mapeado (Z:\) - o Windows resolve em %~dp0.
set "PASTA=%~dp0"

REM Caso UNC, o cd nao funciona diretamente; usamos pushd que mapeia automaticamente.
pushd "%PASTA%" 2>nul
if errorlevel 1 (
    echo.
    echo ERRO: nao consigo acessar a pasta:
    echo   %PASTA%
    echo.
    echo Verifique se voce tem permissao de leitura no compartilhamento.
    echo.
    pause
    exit /b 1
)

echo.
echo Iniciando Calculadora de Producao a partir de:
echo   %PASTA%
echo.

REM ExecutionPolicy Bypass libera scripts vindos da rede (apenas nesta execucao).
REM -AutoPort: escolhe porta livre 8080..8099 (permite multiplos operadores no mesmo PC).
REM -LocalOnly: escuta apenas em localhost (sem precisar de admin/firewall).
REM -OpenBrowser: abre o navegador automaticamente apos iniciar.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0servir.ps1" -AutoPort -LocalOnly -OpenBrowser

popd

echo.
echo Servidor encerrado. Voce ja pode fechar esta janela.
pause >nul
endlocal
