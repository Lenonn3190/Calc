# Calculadora de Impacto de Produção

Calculadora para simular previsões de produção considerando Takt, turnos, intervalos e feriados.

## Estrutura do projeto

```
Calculadora de produção/
├── index.html               # Marcação da aplicação
├── style.css                # Estilos
├── app.js                   # Lógica (cálculos, UI, gráficos, Gantt, cenários)
├── manifest.json            # PWA: nome, ícones, tema
├── sw.js                    # Service Worker (modo offline + network-first para HTML/CSS/JS)
├── parametros.json          # Calendário, turnos e feriados (carregado automaticamente)
├── tests.html               # Testes unitários das funções utilitárias
│
├── servir.ps1               # Servidor HTTP em PowerShell puro (sem instalar nada)
├── iniciar-servidor.bat     # Duplo-clique para subir o servidor
├── parar-servidor.bat       # Encerra o servidor
├── instalar-acl.bat         # Habilita acesso pela rede (1x, como admin)
├── iniciar-no-boot.bat      # Configura inicialização automática com o Windows
├── _serve.js                # Servidor alternativo em Node.js
├── LEIA-ME-PRODUCAO.md      # Guia passo-a-passo para colocar em produção
└── README.md                # Este arquivo
```

## Como usar

### Em produção (PC dedicado da empresa)

Veja o guia completo em **[`LEIA-ME-PRODUCAO.md`](./LEIA-ME-PRODUCAO.md)**. Resumo:

1. Copie a pasta para o PC servidor.
2. Botão direito em `instalar-acl.bat` → "Executar como administrador" (só uma vez).
3. Duplo-clique em `iniciar-servidor.bat`. Os operadores acessam pelo navegador via
   `http://NOME-DO-PC:8080/`.
4. Opcional: duplo-clique em `iniciar-no-boot.bat` para subir automaticamente.

Não é preciso instalar nada — o servidor é PowerShell puro, nativo do Windows.

### Em desenvolvimento

1. **Servidor local**: `iniciar-servidor.bat` (sem instalar nada) ou `node _serve.js`
   (se preferir Node.js).
2. **Arquivo de exemplo**: Coloque um XLSX na pasta e configure o nome em
   `parametros.json` → `arquivoExemplo`.
3. **Carregar parâmetros**: Se abrir via `file://`, use "Carregar JSON" para
   selecionar o `parametros.json` manualmente.

## parametros.json

O arquivo define:

- **takt**, **setupMin**, **rampLossPct**: Parâmetros de produção
- **shift1**, **shift2**: Horários dos turnos (início, fim, 1º KiuKey, 2º KiuKey, almoço)
- **feriados**: Lista de datas no formato `YYYY-MM-DD` (excluídas do calendário produtivo)
- **arquivoExemplo**: Nome do arquivo XLSX de exemplo (opcional)

## PWA / Modo offline

- **Instalável**: Use "Instalar app" (quando disponível) para instalar como aplicativo.
- **Offline**: Com servidor HTTPS, a app funciona sem internet após o primeiro carregamento.
- **Cache**: `index.html`, `parametros.json` e bibliotecas CDN são cacheados.

## Linha do tempo (Gantt)

Após calcular o plano, é exibida uma linha do tempo com barras por lote:
- **Dia**: eixo em horas (visualização detalhada)
- **Semana**: eixo em dias (visão ampla)
- Barras em laranja/vermelho indicam lotes com impacto (componente/motor)

## Ferramentas disponíveis

| Ferramenta | Descrição |
|------------|-----------|
| **Exportar CSV** | Baixa o plano em CSV (separador `;`, UTF-8 com BOM) |
| **Imprimir** | Imprime o plano (ou "Salvar como PDF" no navegador) |
| **Copiar** | Copia o plano formatado para a área de transferência (cole no Excel) |
| **Carregar JSON** | Carrega parâmetros de um arquivo `.json` |
| **Salvar JSON** | Baixa os parâmetros atuais para substituir o `parametros.json` |
| **Salvar cenário** | Salva o plano atual para comparação |
| **Comparar cenários** | Exibe tabela com cenários salvos (término, peças, dias) |

## Persistência

- **Tema** (claro/escuro): salvo em `localStorage`
- **Data de início**: salva em `localStorage` (se não for no passado)
- **Parâmetros**: carregados de `parametros.json` na inicialização

## Testes

Abra `tests.html` no navegador para executar os testes das funções utilitárias (parseQty, timeToMinutes, etc.).
